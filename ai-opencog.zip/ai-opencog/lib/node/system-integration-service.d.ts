/**
 * Copyright (c) 2024 Cognitive Intelligence Ventures.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
import { UserPreferences } from '../common';
import { OpenCogService } from '../common/opencog-service';
export interface SystemIntegrationMetrics {
    cache: {
        hitRate: number;
        size: number;
        performance: number;
    };
    personalization: {
        activeUsers: number;
        adaptations: number;
        satisfaction: number;
    };
    resources: {
        memoryOptimization: number;
        processingEfficiency: number;
        networkOptimization: number;
    };
    feedback: {
        totalFeedback: number;
        averageRating: number;
        improvementActions: number;
    };
    overall: {
        systemHealth: number;
        userSatisfaction: number;
        performanceScore: number;
    };
}
export interface OptimizationResult {
    success: boolean;
    metrics: SystemIntegrationMetrics;
    improvements: Array<{
        component: string;
        description: string;
        impact: number;
    }>;
    recommendations: Array<{
        priority: 'high' | 'medium' | 'low';
        action: string;
        expectedBenefit: string;
    }>;
}
/**
 * Backend service for Phase 5 System Integration and Optimization
 */
export declare class SystemIntegrationService {
    protected readonly opencog: OpenCogService;
    private cognitiveCache;
    private personalization;
    private resourceManager;
    private feedbackIntegration;
    private optimizationTimer?;
    private readonly optimizationInterval;
    constructor();
    /**
     * Perform comprehensive system optimization
     */
    performSystemOptimization(): Promise<OptimizationResult>;
    /**
     * Get comprehensive system metrics
     */
    getSystemMetrics(): Promise<SystemIntegrationMetrics>;
    /**
     * Optimize user experience for a specific user
     */
    optimizeUserExperience(userId: string, preferences?: UserPreferences): Promise<{
        personalizations: Array<{
            feature: string;
            adaptation: string;
        }>;
        recommendations: Array<{
            type: string;
            description: string;
            confidence: number;
        }>;
        cacheOptimizations: Array<{
            key: string;
            improvement: string;
        }>;
    }>;
    /**
     * Process user feedback and apply improvements
     */
    processFeedbackAndImprove(userId: string, feedback: {
        source: string;
        context: any;
        rating: number;
        details?: string;
    }): Promise<{
        feedbackId: string;
        learningPoints: Array<{
            insight: string;
            confidence: number;
        }>;
        immediateActions: Array<{
            action: string;
            description: string;
        }>;
    }>;
    /**
     * Get algorithm optimization recommendations
     */
    getAlgorithmOptimizations(): Promise<Array<{
        algorithm: string;
        currentPerformance: number;
        recommendedChanges: string[];
        expectedImprovement: number;
    }>>;
    /**
     * Start periodic system optimization
     */
    private startPeriodicOptimization;
    /**
     * Stop periodic optimization
     */
    stopPeriodicOptimization(): void;
    /**
     * Dispose service resources
     */
    dispose(): void;
    private getActiveUsersCount;
    private getAdaptationsCount;
    private getTotalFeedbackCount;
    private calculateSystemHealth;
    private calculatePerformanceScore;
    private calculateMemoryOptimization;
    private calculateProcessingEfficiency;
    private generateOptimizationRecommendations;
}
//# sourceMappingURL=system-integration-service.d.ts.map