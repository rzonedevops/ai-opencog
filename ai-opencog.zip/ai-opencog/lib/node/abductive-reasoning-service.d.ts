import { AbductiveReasoningService, GeneratedHypothesis } from '../common/reasoning-services';
import { PLNReasoningEngine } from './reasoning-engines';
/**
 * Implementation of AbductiveReasoningService using OpenCog PLN reasoning
 */
export declare class AbductiveReasoningServiceImpl implements AbductiveReasoningService {
    private readonly reasoningEngine;
    constructor(reasoningEngine: PLNReasoningEngine);
    generateBugHypotheses(symptoms: any[]): Promise<GeneratedHypothesis[]>;
    suggestCreativeSolutions(problem: string, constraints?: any[]): Promise<{
        solutions: string[];
        creativity: number;
    }>;
    proposeArchitectureOptimizations(architecture: any): Promise<{
        optimizations: any[];
        impact: number;
    }>;
    /**
     * Convert symptom to atom for reasoning
     */
    private convertSymptomToAtom;
    /**
     * Extract bug hypotheses from reasoning conclusions
     */
    private extractBugHypotheses;
    /**
     * Convert reasoning conclusion to bug hypothesis
     */
    private conclusionToBugHypothesis;
    /**
     * Extract hypothesis from ImplicationLink
     */
    private extractImplicationHypothesis;
    /**
     * Extract evidence from ImplicationLink
     */
    private extractImplicationEvidence;
    /**
     * Generate test conditions for ImplicationLink
     */
    private generateTestConditionsForImplication;
    /**
     * Extract hypothesis from EvaluationLink
     */
    private extractEvaluationHypothesis;
    /**
     * Generate test conditions for EvaluationLink
     */
    private generateTestConditionsForEvaluation;
    /**
     * Generate common bug pattern hypotheses
     */
    private generateCommonBugHypotheses;
    /**
     * Create problem atom
     */
    private createProblemAtom;
    /**
     * Create constraint atom
     */
    private createConstraintAtom;
    /**
     * Extract creative solutions from conclusions
     */
    private extractCreativeSolutions;
    /**
     * Convert conclusion to solution
     */
    private conclusionToSolution;
    /**
     * Generate fallback creative solutions
     */
    private generateFallbackSolutions;
    /**
     * Calculate creativity score for solutions
     */
    private calculateCreativityScore;
    /**
     * Convert architecture to atoms
     */
    private convertArchitectureToAtoms;
    /**
     * Create component atom
     */
    private createComponentAtom;
    /**
     * Create connection atom
     */
    private createConnectionAtom;
    /**
     * Create pattern atom
     */
    private createPatternAtom;
    /**
     * Extract architecture optimizations
     */
    private extractArchitectureOptimizations;
    /**
     * Convert conclusion to optimization
     */
    private conclusionToOptimization;
    /**
     * Generate common architectural optimizations
     */
    private generateCommonOptimizations;
    /**
     * Calculate optimization impact
     */
    private calculateOptimizationImpact;
}
//# sourceMappingURL=abductive-reasoning-service.d.ts.map