import { InductiveReasoningService, PatternGeneralizationInput, PatternGeneralizationResult } from '../common/reasoning-services';
import { PLNReasoningEngine } from './reasoning-engines';
/**
 * Implementation of InductiveReasoningService using OpenCog PLN reasoning
 */
export declare class InductiveReasoningServiceImpl implements InductiveReasoningService {
    private readonly reasoningEngine;
    constructor(reasoningEngine: PLNReasoningEngine);
    generalizeFromExamples(input: PatternGeneralizationInput): Promise<PatternGeneralizationResult>;
    generateCodeFromPatterns(patterns: any[], context?: string): Promise<{
        code: string;
        confidence: number;
    }>;
    identifyBestPractices(examples: any[]): Promise<{
        practices: string[];
        confidence: number;
    }>;
    /**
     * Convert examples to atoms for inductive reasoning
     */
    private convertExamplesToAtoms;
    /**
     * Create atom from code example
     */
    private createCodeExampleAtom;
    /**
     * Create atom from input-output pair
     */
    private createIOPairAtom;
    /**
     * Create atom from generic example
     */
    private createGenericExampleAtom;
    /**
     * Extract the best pattern from reasoning conclusions
     */
    private extractBestPattern;
    /**
     * Calculate pattern quality score
     */
    private calculatePatternScore;
    /**
     * Convert atom to pattern representation
     */
    private atomToPattern;
    /**
     * Extract structural information from atom
     */
    private extractStructure;
    /**
     * Identify scenarios where pattern is applicable
     */
    private identifyApplicableScenarios;
    /**
     * Calculate generalization strength
     */
    private calculateGeneralizationStrength;
    /**
     * Check if pattern applies to example
     */
    private patternAppliesTo;
    /**
     * Convert pattern to atom
     */
    private convertPatternToAtom;
    /**
     * Detect programming language from context
     */
    private detectLanguage;
    /**
     * Synthesize code from reasoning atoms
     */
    private synthesizeCodeFromAtoms;
    /**
     * Convert atom to code representation
     */
    private atomToCode;
    /**
     * Generate conditional code from ImplicationLink
     */
    private generateConditionalCode;
    /**
     * Generate evaluation code
     */
    private generateEvaluationCode;
    /**
     * Generate concept code
     */
    private generateConceptCode;
    /**
     * Convert example to evaluation atom
     */
    private convertExampleToEvaluationAtom;
    /**
     * Extract best practices from atoms
     */
    private extractBestPractices;
    /**
     * Convert atom to best practice description
     */
    private atomToBestPractice;
}
//# sourceMappingURL=inductive-reasoning-service.d.ts.map