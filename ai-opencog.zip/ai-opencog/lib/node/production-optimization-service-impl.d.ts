import { ILogger } from '@theia/core/lib/common/logger';
import { Event } from '@theia/core/lib/common/event';
import { ProductionOptimizationService } from '../common/production-optimization-service';
import { ProductionMetrics, SystemHealth, ProductionStats, OptimizationResult, AlertConfig, AlertEvent, CacheMetrics, ProductionConfig } from '../common/production-optimization-types';
/**
 * Implementation of the production optimization service
 */
export declare class ProductionOptimizationServiceImpl implements ProductionOptimizationService {
    protected readonly logger: ILogger;
    private config;
    private isMonitoring;
    private metricsHistory;
    private alertConfigs;
    private cache;
    private stats;
    private startTime;
    private readonly onPerformanceAlertEmitter;
    private readonly onHealthChangedEmitter;
    private readonly onOptimizationAppliedEmitter;
    private readonly onMetricsCollectedEmitter;
    readonly onPerformanceAlert: Event<AlertEvent>;
    readonly onHealthChanged: Event<SystemHealth>;
    readonly onOptimizationApplied: Event<OptimizationResult>;
    readonly onMetricsCollected: Event<ProductionMetrics>;
    private monitoringIntervals;
    constructor();
    getMetrics(): Promise<ProductionMetrics>;
    getHealth(): Promise<SystemHealth>;
    getStats(): Promise<ProductionStats>;
    startMonitoring(): Promise<void>;
    stopMonitoring(): Promise<void>;
    optimizePerformance(type: string): Promise<OptimizationResult>;
    configureAlerts(alerts: AlertConfig[]): Promise<void>;
    getCacheMetrics(): Promise<CacheMetrics>;
    clearCache(pattern?: string): Promise<void>;
    exportMetrics(format: 'json' | 'csv', timeRange?: {
        start: number;
        end: number;
    }): Promise<string>;
    getConfig(): Promise<ProductionConfig>;
    updateConfig(config: Partial<ProductionConfig>): Promise<void>;
    healthCheck(): Promise<SystemHealth>;
    forceGarbageCollection(): Promise<void>;
    optimizeMemory(): Promise<OptimizationResult>;
    getResourceHistory(hours: number): Promise<ProductionMetrics[]>;
    private collectMetrics;
    private performHealthCheck;
    private checkServiceHealth;
    private checkAlerts;
    private getMetricValue;
    private evaluateAlert;
    private optimizeCache;
    private optimizeConnections;
    private optimizeQueries;
    private performGeneralOptimization;
    private cleanupExpiredCache;
    private calculateCacheSize;
    private calculateCpuUsagePercent;
    private calculateAverageResponseTime;
    private calculateThroughput;
    private calculateErrorRate;
    private getActiveConnectionCount;
    private calculateCacheHitRate;
    private convertToCsv;
    private getDefaultConfig;
    private initializeStats;
}
//# sourceMappingURL=production-optimization-service-impl.d.ts.map