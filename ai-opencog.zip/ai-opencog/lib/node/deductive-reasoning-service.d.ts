import { DeductiveReasoningService, CodeLogicResult, ReasoningResult } from '../common/reasoning-services';
import { PLNReasoningEngine } from './reasoning-engines';
/**
 * Implementation of DeductiveReasoningService using OpenCog PLN reasoning
 */
export declare class DeductiveReasoningServiceImpl implements DeductiveReasoningService {
    private readonly reasoningEngine;
    constructor(reasoningEngine: PLNReasoningEngine);
    verifyCodeLogic(code: string): Promise<CodeLogicResult>;
    deduceConclusions(premises: any[]): Promise<ReasoningResult>;
    checkConsistency(statements: any[]): Promise<{
        isConsistent: boolean;
        conflicts?: any[];
    }>;
    /**
     * Parse code into logical atoms for reasoning
     */
    private parseCodeToAtoms;
    /**
     * Create conditional atom from if statement
     */
    private createConditionalAtom;
    /**
     * Create return atom from return statement
     */
    private createReturnAtom;
    /**
     * Create assignment atom from assignment statement
     */
    private createAssignmentAtom;
    /**
     * Convert generic premise to atom
     */
    private convertToAtom;
    /**
     * Analyze reasoning results for logic issues
     */
    private analyzeLogicIssues;
    /**
     * Find contradictions in atom set
     */
    private findContradictions;
    /**
     * Check if two atoms are contradictory
     */
    private areContradictory;
    /**
     * Generate suggestions based on issues and reasoning results
     */
    private generateSuggestions;
}
//# sourceMappingURL=deductive-reasoning-service.d.ts.map