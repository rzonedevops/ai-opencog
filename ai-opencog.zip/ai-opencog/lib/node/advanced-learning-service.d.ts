import { AdvancedLearningService } from '../common/advanced-learning-service';
import { AdvancedLearningType, AdvancedLearningData, AdvancedLearningResult, AdvancedLearningModel, TensorData, Tensor3D } from '../common/opencog-types';
/**
 * Backend implementation of Advanced Learning Service
 */
export declare class AdvancedLearningServiceImpl implements AdvancedLearningService {
    private models;
    private nextModelId;
    createAdvancedModel(type: AdvancedLearningType, config: any): Promise<AdvancedLearningModel>;
    trainAdvancedModel(modelId: string, data: AdvancedLearningData[]): Promise<AdvancedLearningResult>;
    predict(modelId: string, input: TensorData | Tensor3D | any): Promise<AdvancedLearningResult>;
    evaluateModel(modelId: string, testData: AdvancedLearningData[]): Promise<AdvancedLearningResult>;
    updateModel(modelId: string, data: AdvancedLearningData[]): Promise<AdvancedLearningResult>;
    getModelInfo(modelId: string): Promise<AdvancedLearningModel | undefined>;
    listModels(type?: AdvancedLearningType): Promise<AdvancedLearningModel[]>;
    deleteModel(modelId: string): Promise<boolean>;
    getStats(): Promise<{
        totalModels: number;
        typeDistribution: Record<AdvancedLearningType, number>;
        averagePerformance: Record<AdvancedLearningType, number>;
        memoryUsage: number;
    }>;
    private initializeModelState;
    private getCapabilities;
    private estimateParameters;
    private performAdvancedTraining;
    private simulateTrainingStep;
    private performPrediction;
    private calculatePredictionConfidence;
    private performEvaluation;
    private performIncrementalUpdate;
}
//# sourceMappingURL=advanced-learning-service.d.ts.map