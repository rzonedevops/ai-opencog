import { SupervisedLearningService, LearningResult } from '../common/learning-services';
import { UserFeedback, LearningContext } from '../common/opencog-types';
/**
 * Implementation of SupervisedLearningService
 * Learns from labeled data and user feedback
 */
export declare class SupervisedLearningServiceImpl implements SupervisedLearningService {
    private readonly learningHistory;
    private readonly userFeedbackHistory;
    private readonly modelAccuracy;
    learnFromFeedback(action: string, feedback: UserFeedback): Promise<LearningResult>;
    trainWithExamples(examples: {
        input: any;
        output: any;
    }[]): Promise<LearningResult>;
    predictOutcome(input: any, context?: LearningContext): Promise<{
        prediction: any;
        confidence: number;
    }>;
    /**
     * Calculate priority based on feedback
     */
    private calculatePriority;
    /**
     * Update model based on feedback
     */
    private updateModel;
    /**
     * Calculate accuracy for an action
     */
    private calculateAccuracy;
    /**
     * Calculate confidence from feedback
     */
    private calculateConfidence;
    /**
     * Generate insights from feedback
     */
    private generateInsights;
    /**
     * Serialize input for consistent key generation
     */
    private serializeInput;
    /**
     * Find similar historical data for prediction
     */
    private findSimilarHistory;
    /**
     * Calculate string similarity (simple implementation)
     */
    private calculateSimilarity;
    /**
     * Predict outcome from similar history
     */
    private predictFromSimilarHistory;
    /**
     * Count outcome occurrences
     */
    private countOutcomes;
    /**
     * Get most common outcome
     */
    private getMostCommonOutcome;
    /**
     * Apply context adjustments to confidence
     */
    private applyContextAdjustments;
    /**
     * Get history for specific project type
     */
    private getProjectTypeHistory;
}
//# sourceMappingURL=supervised-learning-service.d.ts.map