import { Agent } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { OpenCogService } from '../common/opencog-service';
/**
 * Server-side OpenCog-powered code analysis agent as specified in Phase 2 requirements
 */
export declare class CodeAnalysisAgent extends Agent {
    private opencog;
    private workspace;
    constructor(opencog: OpenCogService, workspace: WorkspaceService);
    analyzeCode(fileUri: string): Promise<any>;
    private extractCodeAtoms;
}
//# sourceMappingURL=code-analysis-agent.d.ts.map