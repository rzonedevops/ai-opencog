import { UnsupervisedLearningService, PatternDiscoveryResult, WorkflowOptimizationResult } from '../common/learning-services';
import { PatternMatchingEngine } from './reasoning-engines';
/**
 * Implementation of UnsupervisedLearningService
 * Discovers patterns and learns without labeled data
 */
export declare class UnsupervisedLearningServiceImpl implements UnsupervisedLearningService {
    private readonly patternEngine;
    private readonly discoveredPatterns;
    private readonly workflowData;
    private readonly qualityMetricsHistory;
    constructor(patternEngine: PatternMatchingEngine);
    discoverCodePatterns(codeData: any[]): Promise<PatternDiscoveryResult>;
    learnWorkflowOptimizations(workflowData: any[]): Promise<WorkflowOptimizationResult>;
    learnQualityMetrics(qualityData: any[]): Promise<{
        metrics: any[];
        confidence: number;
    }>;
    /**
     * Group similar code snippets
     */
    private groupSimilarCode;
    /**
     * Determine which group code belongs to
     */
    private determineCodeGroup;
    /**
     * Discover patterns within a code group
     */
    private discoverPatternsInGroup;
    /**
     * Analyze structural patterns in code group
     */
    private analyzeStructuralPattern;
    /**
     * Find common structures in code group
     */
    private findCommonStructures;
    /**
     * Analyze naming patterns in code group
     */
    private analyzeNamingPattern;
    /**
     * Extract naming conventions from code group
     */
    private extractNamingConventions;
    /**
     * Analyze complexity patterns
     */
    private analyzeComplexityPattern;
    /**
     * Calculate simple code complexity metric
     */
    private calculateCodeComplexity;
    /**
     * Calculate nesting level in code
     */
    private calculateNestingLevel;
    /**
     * Get complexity distribution
     */
    private getComplexityDistribution;
    /**
     * Calculate pattern discovery confidence
     */
    private calculatePatternConfidence;
    /**
     * Generate insights from discovered patterns
     */
    private generatePatternInsights;
    /**
     * Analyze time patterns in workflow data
     */
    private analyzeTimePatterns;
    /**
     * Calculate variance
     */
    private calculateVariance;
    /**
     * Analyze frequency patterns in workflow data
     */
    private analyzeFrequencyPatterns;
    /**
     * Analyze sequence patterns in workflow data
     */
    private analyzeSequencePatterns;
    /**
     * Find common subsequences
     */
    private findCommonSubsequences;
    /**
     * Generate time-based optimizations
     */
    private generateTimeOptimizations;
    /**
     * Generate frequency-based optimizations
     */
    private generateFrequencyOptimizations;
    /**
     * Generate sequence-based optimizations
     */
    private generateSequenceOptimizations;
    /**
     * Calculate expected improvement from optimizations
     */
    private calculateExpectedImprovement;
    /**
     * Calculate optimization confidence
     */
    private calculateOptimizationConfidence;
    /**
     * Discover quality metric patterns
     */
    private discoverQualityMetricPatterns;
    /**
     * Extract quality attributes from data
     */
    private extractQualityAttributes;
    /**
     * Analyze pattern for a quality attribute
     */
    private analyzeAttributePattern;
    /**
     * Calculate trend in values
     */
    private calculateTrend;
    /**
     * Extract quality metrics from patterns
     */
    private extractQualityMetrics;
    /**
     * Calculate metric confidence
     */
    private calculateMetricConfidence;
}
//# sourceMappingURL=unsupervised-learning-service.d.ts.map