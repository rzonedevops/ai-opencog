import { Atom, AtomPattern, ReasoningQuery, ReasoningResult, LearningData, PatternInput, PatternResult, OpenCogService, LearningModel, AdaptationStrategy, UserBehaviorPattern, LearningContext, UserFeedback, KnowledgeManagementService, MultiModalData, MultiModalPatternInput, MultiModalPatternResult, MultiModalLearningData, ModalityType, TensorData, Tensor3D, AdvancedLearningType, AdvancedLearningData, AdvancedLearningResult, AdvancedLearningModel, NeuralNetworkConfig, MetaLearningConfig } from '../common';
/**
 * AtomSpace implementation for storing and managing OpenCog atoms
 * Enhanced with knowledge management capabilities, learning and adaptation, and advanced reasoning engines
 */
export declare class AtomSpaceService implements OpenCogService {
    private atoms;
    private nextAtomId;
    private knowledgeManagementService;
    private learningModels;
    private adaptationStrategies;
    private userBehaviorPatterns;
    private userPersonalization;
    private learningHistory;
    private nextModelId;
    private plnEngine;
    private patternEngine;
    private codeAnalysisEngine;
    private multiModalService;
    constructor();
    addAtom(atom: Atom): Promise<string>;
    queryAtoms(pattern: AtomPattern): Promise<Atom[]>;
    removeAtom(atomId: string): Promise<boolean>;
    updateAtom(atomId: string, updates: Partial<Atom>): Promise<boolean>;
    reason(query: ReasoningQuery): Promise<ReasoningResult>;
    learn(data: LearningData): Promise<void>;
    learnFromFeedback(feedback: UserFeedback, context: LearningContext): Promise<void>;
    adaptToUser(userId: string, domain: string, data: any): Promise<AdaptationStrategy>;
    getAdaptationStrategy(userId: string, domain: string): Promise<AdaptationStrategy | undefined>;
    learnUserBehavior(userId: string, action: string, context: any): Promise<void>;
    getUserBehaviorPatterns(userId: string): Promise<UserBehaviorPattern[]>;
    predictUserAction(userId: string, context: any): Promise<{
        action: string;
        confidence: number;
    }[]>;
    createLearningModel(type: string, parameters?: Record<string, any>): Promise<LearningModel>;
    updateLearningModel(modelId: string, trainingData: LearningData[]): Promise<LearningModel>;
    getLearningModel(modelId: string): Promise<LearningModel | undefined>;
    listLearningModels(): Promise<LearningModel[]>;
    personalize(userId: string, preferences: Record<string, any>): Promise<void>;
    getPersonalization(userId: string): Promise<Record<string, any>>;
    getLearningStats(): Promise<{
        totalLearningRecords: number;
        modelAccuracy: Record<string, number>;
        userAdaptations: number;
        behaviorPatterns: number;
    }>;
    recognizePatterns(input: PatternInput): Promise<PatternResult[]>;
    getAtomSpaceSize(): Promise<number>;
    clearAtomSpace(): Promise<void>;
    exportAtomSpace(): Promise<string>;
    importAtomSpace(data: string): Promise<void>;
    private generateAtomId;
    private matchesPattern;
    /**
     * Perform advanced code completion using cognitive reasoning
     */
    private performAdvancedCodeCompletion;
    /**
     * Perform hybrid reasoning combining multiple engines
     */
    private performHybridReasoning;
    /**
     * Update reasoning capabilities based on learning data
     */
    private updateReasoningCapabilities;
    /**
     * Analyze code context for completion
     */
    private analyzeCodeContext;
    /**
     * Generate pattern-based completions
     */
    private generatePatternBasedCompletions;
    /**
     * Generate reasoning-based completions
     */
    private generateReasoningBasedCompletions;
    /**
     * Rank completion suggestions
     */
    private rankCompletionSuggestions;
    /**
     * Calculate suggestion score
     */
    private calculateSuggestionScore;
    /**
     * Calculate context relevance
     */
    private calculateContextRelevance;
    /**
     * Calculate completion confidence
     */
    private calculateCompletionConfidence;
    /**
     * Combine multiple reasoning results
     */
    private combineReasoningResults;
    /**
     * Helper methods for context analysis
     */
    private extractCurrentScope;
    private extractAvailableSymbols;
    private getRecentPatterns;
    private extractSemanticContext;
    /**
     * Detect general patterns in input data
     */
    private detectPatterns;
    /**
     * Recognize code patterns in source code
     */
    private recognizeCodePatterns;
    /**
     * Recognize structural patterns in data arrays
     */
    private recognizeStructuralPatterns;
    /**
     * Recognize behavioral patterns in interaction data
     */
    private recognizeBehavioralPatterns;
    /**
     * Score pattern confidence based on various factors
     */
    private scorePatternConfidence;
    /**
     * Calculate confidence for code patterns
     */
    private calculateCodePatternConfidence;
    /**
     * Assess complexity of detected patterns
     */
    private assessPatternComplexity;
    /**
     * Detect sequence patterns in data
     */
    private detectSequencePattern;
    /**
     * Detect repetition patterns
     */
    private detectRepetitionPattern;
    /**
     * Detect hierarchical patterns
     */
    private detectHierarchicalPattern;
    /**
     * Calculate data variability
     */
    private calculateVariability;
    /**
     * Analyze interaction patterns
     */
    private analyzeInteractionPattern;
    /**
     * Analyze usage patterns
     */
    private analyzeUsagePattern;
    /**
     * Calculate timespan for interactions
     */
    private calculateTimespan;
    /**
     * Calculate interaction frequency
     */
    private calculateInteractionFrequency;
    /**
     * Calculate usage efficiency
     */
    private calculateUsageEfficiency;
    /**
     * Calculate consistency of time intervals
     */
    private calculateConsistency;
    private generateSessionId;
    private determinePriority;
    private processSupervisedLearning;
    private processUnsupervisedLearning;
    private processReinforcementLearning;
    private processPersonalizationLearning;
    private processBehavioralLearning;
    private processAdaptiveLearning;
    private updateAdaptationFromFeedback;
    private analyzeUserData;
    private calculateEffectiveness;
    private updateBehaviorPatterns;
    private calculateContextSimilarity;
    private calculateModelAccuracy;
    private calculatePredictionAccuracy;
    private extractPatterns;
    private calculateReward;
    private updateUserModel;
    private determineExperienceLevel;
    private identifyPreferredWorkflow;
    private identifyOptimizationAreas;
    /**
     * Process single multi-modal data
     */
    processMultiModalData(data: MultiModalData): Promise<MultiModalData>;
    /**
     * Process batch of multi-modal data
     */
    processMultiModalBatch(data: MultiModalData[]): Promise<MultiModalData[]>;
    /**
     * Recognize patterns in multi-modal data
     */
    recognizeMultiModalPatterns(input: MultiModalPatternInput): Promise<MultiModalPatternResult[]>;
    /**
     * Learn from multi-modal data
     */
    learnFromMultiModalData(data: MultiModalLearningData): Promise<void>;
    /**
     * Get multi-modal learning statistics
     */
    getMultiModalLearningStats(): Promise<{
        totalMultiModalRecords: number;
        modalityDistribution: Record<ModalityType, number>;
        crossModalPatterns: number;
        processingAccuracy: Record<ModalityType, number>;
    }>;
    /**
     * Process tensor data with 4 degrees of freedom
     */
    processTensorData(tensor: TensorData): Promise<TensorData>;
    /**
     * Perform specific tensor operation
     */
    performTensorOperation(tensor: TensorData, operation: string, parameters?: Record<string, any>): Promise<TensorData>;
    /**
     * Fuse multiple tensor data
     */
    fuseTensorData(tensors: TensorData[], strategy?: 'concatenation' | 'addition' | 'attention' | 'learned'): Promise<TensorData>;
    /**
     * Cross-modal reasoning
     */
    reasonAcrossModalities(query: ReasoningQuery, modalData: MultiModalData[]): Promise<ReasoningResult>;
    /**
     * Analyze multi-modal context
     */
    analyzeMultiModalContext(data: MultiModalData[]): Promise<{
        context: any;
        dominantModality: ModalityType;
        modalityInteractions: Array<{
            source: ModalityType;
            target: ModalityType;
            interaction: string;
            strength: number;
        }>;
        cognitiveLoad: number;
    }>;
    /**
     * Apply attention mechanisms for multi-modal data
     */
    applyAttentionMechanism(data: MultiModalData[], attentionType: 'spatial' | 'temporal' | 'cross-modal' | 'cognitive'): Promise<{
        attentionWeights: Record<string, number>;
        focusedData: MultiModalData[];
        attentionMap?: number[];
    }>;
    /**
     * 3 DoF tensor operations
     */
    processTensor3D(tensor: Tensor3D): Promise<Tensor3D>;
    performTensor3DOperation(tensor: Tensor3D, operation: string, parameters?: Record<string, any>): Promise<Tensor3D>;
    fuseTensor3DData(tensors: Tensor3D[], strategy?: 'concatenation' | 'addition' | 'attention' | 'learned'): Promise<Tensor3D>;
    /**
     * Advanced learning algorithms
     */
    trainAdvancedModel(data: AdvancedLearningData): Promise<AdvancedLearningResult>;
    predictWithAdvancedModel(modelId: string, input: TensorData | Tensor3D | any): Promise<AdvancedLearningResult>;
    updateAdvancedModel(modelId: string, data: AdvancedLearningData): Promise<AdvancedLearningResult>;
    /**
     * Neural network operations
     */
    createNeuralNetwork(config: NeuralNetworkConfig): Promise<AdvancedLearningModel>;
    trainNeuralNetwork(modelId: string, data: AdvancedLearningData[]): Promise<AdvancedLearningResult>;
    evaluateNeuralNetwork(modelId: string, testData: AdvancedLearningData[]): Promise<AdvancedLearningResult>;
    /**
     * Meta-learning operations
     */
    initializeMetaLearning(config: MetaLearningConfig): Promise<AdvancedLearningModel>;
    metaLearn(modelId: string, tasks: AdvancedLearningData[][]): Promise<AdvancedLearningResult>;
    adaptToNewTask(modelId: string, taskData: AdvancedLearningData[], shots: number): Promise<AdvancedLearningResult>;
    /**
     * Get advanced learning statistics
     */
    getAdvancedLearningStats(): Promise<{
        totalAdvancedModels: number;
        modelTypeDistribution: Record<AdvancedLearningType, number>;
        averageAccuracy: Record<AdvancedLearningType, number>;
        totalTrainingTime: number;
        memoryUsage: number;
    }>;
    private calculateFusedShape3D;
    private performAdvancedTraining;
    private performAdvancedPrediction;
    private estimateNetworkParameters;
    getKnowledgeManagementService(): KnowledgeManagementService;
}
//# sourceMappingURL=atomspace-service.d.ts.map