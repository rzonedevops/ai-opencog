import { MultiModalData, MultiModalPatternInput, MultiModalPatternResult, ModalityType, TensorData } from '../common/opencog-types';
/**
 * Multi-modal cognitive processing service implementing Phase 5 advanced features.
 * Supports text, image, audio, and tensor data processing with 4 degrees of freedom.
 */
export declare class MultiModalProcessingService {
    private processingHistory;
    private modalityStats;
    private crossModalPatterns;
    constructor();
    /**
     * Process single multi-modal data
     */
    processMultiModalData(data: MultiModalData): Promise<MultiModalData>;
    /**
     * Process batch of multi-modal data
     */
    processMultiModalBatch(dataArray: MultiModalData[]): Promise<MultiModalData[]>;
    /**
     * Recognize patterns in multi-modal data
     */
    recognizeMultiModalPatterns(input: MultiModalPatternInput): Promise<MultiModalPatternResult[]>;
    /**
     * Process tensor data with 4 degrees of freedom
     */
    processTensorData(tensor: TensorData): Promise<TensorData>;
    /**
     * Perform specific tensor operation
     */
    performTensorOperation(tensor: TensorData, operation: string, parameters?: Record<string, any>): Promise<TensorData>;
    /**
     * Fuse multiple tensor data
     */
    fuseTensorData(tensors: TensorData[], strategy?: 'concatenation' | 'addition' | 'attention' | 'learned'): Promise<TensorData>;
    /**
     * Get multi-modal learning statistics
     */
    getMultiModalLearningStats(): {
        totalMultiModalRecords: number;
        modalityDistribution: Record<ModalityType, number>;
        crossModalPatterns: number;
        processingAccuracy: Record<ModalityType, number>;
    };
    private processTextData;
    private processImageData;
    private processAudioData;
    private processTensorDataInternal;
    private processMixedModalData;
    private extractSemanticAnnotations;
    private extractImageFeatures;
    private extractAudioFeatures;
    private performTensorOperations;
    private applyConvolution;
    private applyPooling;
    private applyNormalization;
    private applyActivation;
    private applyAttention;
    private recognizePatternsInModality;
    private recognizeCrossModalPatterns;
    private fusePatternResults;
    private analyzeCrossModalRelationships;
    private areShapesCompatible;
    private concatenateTensors;
    private addTensors;
    private attentionFuseTensors;
    private learnedFuseTensors;
    private getDataSize;
    private recordProcessingStep;
}
//# sourceMappingURL=multi-modal-processing-service.d.ts.map