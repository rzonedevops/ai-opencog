import { KnowledgeManagementService } from '../common/knowledge-management-service';
import { KnowledgeGraph, KnowledgeCategory, KnowledgeDiscoveryQuery, KnowledgeDiscoveryResult, KnowledgeValidationResult, KnowledgePersistenceConfig, KnowledgeTransferOptions, KnowledgeMetrics, KnowledgeRelationship } from '../common/knowledge-management-types';
import { Atom } from '../common/opencog-types';
/**
 * Implementation of Knowledge Management Service
 */
export declare class KnowledgeManagementServiceImpl implements KnowledgeManagementService {
    private knowledgeGraphs;
    private categories;
    private persistenceConfig;
    private nextGraphId;
    private nextCategoryId;
    private nextRelationshipId;
    createKnowledgeGraph(name: string, domain: string, description?: string): Promise<KnowledgeGraph>;
    getKnowledgeGraph(graphId: string): Promise<KnowledgeGraph | undefined>;
    getKnowledgeGraphs(domain?: string): Promise<KnowledgeGraph[]>;
    updateKnowledgeGraph(graphId: string, updates: Partial<KnowledgeGraph>): Promise<boolean>;
    deleteKnowledgeGraph(graphId: string): Promise<boolean>;
    addAtomToGraph(graphId: string, atom: Atom): Promise<boolean>;
    removeAtomFromGraph(graphId: string, atomId: string): Promise<boolean>;
    addRelationship(graphId: string, relationship: KnowledgeRelationship): Promise<boolean>;
    removeRelationship(graphId: string, relationshipId: string): Promise<boolean>;
    discoverKnowledge(query: KnowledgeDiscoveryQuery): Promise<KnowledgeDiscoveryResult[]>;
    findSimilarConcepts(atomId: string, maxResults?: number): Promise<KnowledgeDiscoveryResult[]>;
    getConceptPath(sourceAtomId: string, targetAtomId: string): Promise<KnowledgeRelationship[]>;
    getRelatedConcepts(atomId: string, maxDistance: number): Promise<Atom[]>;
    createCategory(category: KnowledgeCategory): Promise<string>;
    getCategories(): Promise<KnowledgeCategory[]>;
    categorizeAtoms(graphId: string): Promise<Map<string, string[]>>;
    getAtomsByCategory(categoryId: string): Promise<Atom[]>;
    validateKnowledgeGraph(graphId: string): Promise<KnowledgeValidationResult>;
    validateAtom(atomId: string): Promise<KnowledgeValidationResult>;
    detectContradictions(graphId?: string): Promise<KnowledgeValidationResult>;
    configurePersistence(config: KnowledgePersistenceConfig): Promise<void>;
    saveKnowledgeGraph(graphId: string): Promise<boolean>;
    loadKnowledgeGraph(graphId: string): Promise<KnowledgeGraph | undefined>;
    exportKnowledgeGraph(graphId: string, options: KnowledgeTransferOptions): Promise<string>;
    importKnowledgeGraph(data: string, options: KnowledgeTransferOptions): Promise<string>;
    getKnowledgeMetrics(): Promise<KnowledgeMetrics>;
    optimizeKnowledgeGraphs(): Promise<void>;
    getGraphUsageStats(graphId: string): Promise<Record<string, any>>;
    recommendImprovements(graphId: string): Promise<string[]>;
    searchAtoms(query: string, options?: {
        domains?: string[];
        categories?: string[];
        maxResults?: number;
    }): Promise<Atom[]>;
    executeKnowledgeQuery(query: any): Promise<any>;
    private generateGraphId;
    private generateCategoryId;
    private generateRelationshipId;
    private updateQualityMetrics;
    private calculateRelevanceScore;
    private findRelationshipPath;
    private generateDiscoveryExplanation;
    private evaluateCategoryRule;
    private findContradictions;
    private generateValidationSuggestions;
    private estimateMemoryUsage;
}
//# sourceMappingURL=knowledge-management-service-impl.d.ts.map