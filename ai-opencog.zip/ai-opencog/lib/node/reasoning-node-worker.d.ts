import { ILogger } from '@theia/core/lib/common/logger';
import { ReasoningNodeWorker } from '../common/distributed-reasoning-service';
import { ReasoningCapability, NodePerformance } from '../common/distributed-reasoning-types';
import { ReasoningQuery, ReasoningResult } from '../common/opencog-types';
import { PLNReasoningEngine, PatternMatchingEngine, CodeAnalysisReasoningEngine } from './reasoning-engines';
/**
 * Implementation of a reasoning node worker that can execute reasoning tasks
 */
export declare class ReasoningNodeWorkerImpl implements ReasoningNodeWorker {
    protected readonly logger: ILogger;
    protected readonly plnEngine: PLNReasoningEngine;
    protected readonly patternEngine: PatternMatchingEngine;
    protected readonly codeAnalysisEngine: CodeAnalysisReasoningEngine;
    private nodeId;
    private capabilities;
    private status;
    private currentWorkload;
    private performance;
    private activeTasks;
    private maxConcurrentTasks;
    constructor();
    /**
     * Execute a reasoning task
     */
    executeTask(query: ReasoningQuery, constraints?: any): Promise<ReasoningResult>;
    /**
     * Get node capabilities
     */
    getCapabilities(): ReasoningCapability[];
    /**
     * Get current node status and performance
     */
    getStatus(): Promise<{
        status: string;
        workload: number;
        performance: NodePerformance;
    }>;
    /**
     * Shutdown the node gracefully
     */
    shutdown(): Promise<void>;
    /**
     * Get node ID
     */
    getNodeId(): string;
    /**
     * Update node capabilities (for dynamic reconfiguration)
     */
    updateCapabilities(capabilities: ReasoningCapability[]): void;
    /**
     * Set maximum concurrent tasks
     */
    setMaxConcurrentTasks(max: number): void;
    private updateWorkload;
    private updatePerformanceMetrics;
    private generateNodeId;
}
//# sourceMappingURL=reasoning-node-worker.d.ts.map