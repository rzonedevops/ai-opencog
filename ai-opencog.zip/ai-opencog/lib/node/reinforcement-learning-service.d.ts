import { ReinforcementLearningService, LearningResult, OutcomeBasedInput, SuccessPattern } from '../common/learning-services';
import { LearningContext } from '../common/opencog-types';
/**
 * Implementation of ReinforcementLearningService
 * Learns from outcomes and rewards to optimize behavior
 */
export declare class ReinforcementLearningServiceImpl implements ReinforcementLearningService {
    private readonly outcomeHistory;
    private readonly successPatterns;
    private readonly actionValues;
    private readonly learningRate;
    private readonly discountFactor;
    private readonly explorationRate;
    learnFromOutcome(input: OutcomeBasedInput): Promise<LearningResult>;
    recognizeSuccessPatterns(data: any[]): Promise<SuccessPattern[]>;
    optimizeAdaptiveAssistance(userId: string, context: LearningContext): Promise<{
        optimizations: any[];
        confidence: number;
    }>;
    /**
     * Normalize action for consistent key generation
     */
    private normalizeAction;
    /**
     * Calculate reward based on outcome
     */
    private calculateReward;
    /**
     * Update Q-value using Q-learning algorithm
     */
    private updateQValue;
    /**
     * Get maximum future Q-value (simplified - would use state transitions in full implementation)
     */
    private getMaxFutureQValue;
    /**
     * Get actions related to the current action
     */
    private getRelatedActions;
    /**
     * Update success patterns based on outcome
     */
    private updateSuccessPatterns;
    /**
     * Extract context pattern from learning context
     */
    private extractContextPattern;
    /**
     * Check if two patterns match
     */
    private patternsMatch;
    /**
     * Update success rate using exponential moving average
     */
    private updateSuccessRate;
    /**
     * Extract applicable contexts from learning context
     */
    private extractApplicableContexts;
    /**
     * Calculate action accuracy based on historical outcomes
     */
    private calculateActionAccuracy;
    /**
     * Calculate learning confidence
     */
    private calculateLearningConfidence;
    /**
     * Generate insights from outcome learning
     */
    private generateOutcomeLearningInsights;
    /**
     * Group data by action for pattern analysis
     */
    private groupDataByAction;
    /**
     * Extract success patterns for a specific action
     */
    private extractSuccessPatternsForAction;
    /**
     * Group data by context for pattern analysis
     */
    private groupByContext;
    /**
     * Generate context key for grouping
     */
    private generateContextKey;
    /**
     * Parse context key back to readable format
     */
    private parseContextKey;
    /**
     * Extract action from success pattern
     */
    private extractActionFromPattern;
    /**
     * Get user history for personalization
     */
    private getUserHistory;
    /**
     * Get contextual history
     */
    private getContextualHistory;
    /**
     * Check if contexts match
     */
    private contextMatches;
    /**
     * Generate personalization optimizations
     */
    private generatePersonalizationOptimizations;
    /**
     * Generate contextual optimizations
     */
    private generateContextualOptimizations;
    /**
     * Generate adaptive behavior optimizations
     */
    private generateAdaptiveBehaviorOptimizations;
    /**
     * Calculate optimization confidence
     */
    private calculateOptimizationConfidence;
}
//# sourceMappingURL=reinforcement-learning-service.d.ts.map