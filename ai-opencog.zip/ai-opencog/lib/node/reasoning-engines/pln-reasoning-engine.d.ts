import { ReasoningQuery, ReasoningResult } from '../../common';
/**
 * Probabilistic Logic Networks (PLN) reasoning engine
 * Implements probabilistic inference using OpenCog's PLN framework
 */
export declare class PLNReasoningEngine {
    /**
     * Perform PLN-based reasoning on the given query
     */
    reason(query: ReasoningQuery): Promise<ReasoningResult>;
    /**
     * Deductive inference using PLN rules
     */
    private performDeductiveInference;
    /**
     * Apply modus ponens rule
     */
    private applyModusPonens;
    /**
     * Check if an atom is considered true with sufficient confidence
     */
    private isAtomTrue;
    /**
     * Inductive inference using PLN
     */
    private performInductiveInference;
    /**
     * Find inductive patterns in observations
     */
    private findInductivePatterns;
    /**
     * Group observations by their predicate
     */
    private groupObservationsByPredicate;
    /**
     * Extract inductive pattern from grouped observations
     */
    private extractInductivePattern;
    /**
     * Abductive inference using PLN
     */
    private performAbductiveInference;
    /**
     * General PLN inference for other reasoning types
     */
    private performGeneralInference;
    /**
     * Generate abductive hypotheses
     */
    private generateAbductiveHypotheses;
    /**
     * Generate possible causes for an observation
     */
    private generatePossibleCauses;
    /**
     * Rank hypotheses by plausibility
     */
    private rankHypothesesByPlausibility;
    /**
     * Calculate hypothesis plausibility score
     */
    private calculateHypothesisScore;
    /**
     * Check if hypothesis explains observation
     */
    private hypothesisExplainsObservation;
    /**
     * Check if two atoms are related
     */
    private atomsAreRelated;
    /**
     * Apply general PLN rules
     */
    private applyGeneralPLNRules;
    /**
     * Apply AndLink-specific PLN rules
     */
    private applyAndLinkRules;
    /**
     * Apply OrLink-specific PLN rules
     */
    private applyOrLinkRules;
    /**
     * Apply NotLink-specific PLN rules
     */
    private applyNotLinkRules;
    /**
     * Apply SimilarityLink-specific PLN rules
     */
    private applySimilarityRules;
    /**
     * Calculate confidence for inference results
     */
    private calculateInferenceConfidence;
    /**
     * Calculate confidence for pattern recognition
     */
    private calculatePatternConfidence;
    /**
     * Calculate confidence for abductive reasoning
     */
    private calculateAbductiveConfidence;
    /**
     * Calculate general confidence
     */
    private calculateGeneralConfidence;
    /**
     * Extract applied rules for metadata
     */
    private extractAppliedRules;
}
//# sourceMappingURL=pln-reasoning-engine.d.ts.map