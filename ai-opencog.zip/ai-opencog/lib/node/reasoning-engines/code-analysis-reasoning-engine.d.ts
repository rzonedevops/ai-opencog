import { ReasoningQuery, ReasoningResult } from '../../common';
/**
 * Specialized code analysis reasoning engine
 * Performs cognitive analysis of code structure, patterns, and quality
 */
export declare class CodeAnalysisReasoningEngine {
    /**
     * Perform code analysis reasoning
     */
    reason(query: ReasoningQuery): Promise<ReasoningResult>;
    /**
     * Perform comprehensive code analysis
     */
    private performComprehensiveCodeAnalysis;
    /**
     * Analyze code structure
     */
    private analyzeCodeStructure;
    /**
     * Analyze code quality
     */
    private analyzeCodeQuality;
    /**
     * Analyze design patterns
     */
    private analyzeDesignPatterns;
    /**
     * Analyze complexity metrics
     */
    private analyzeComplexity;
    /**
     * Analyze security aspects
     */
    private analyzeSecurityAspects;
    /**
     * Analyze performance aspects
     */
    private analyzePerformance;
    /**
     * Create insight atom
     */
    private createInsightAtom;
    /**
     * Estimate function complexity
     */
    private estimateFunctionComplexity;
    /**
     * Pattern detection methods
     */
    private detectMVCPattern;
    private detectSingletonPattern;
    private detectFactoryPattern;
    private detectBuilderPattern;
    private detectAdapterPattern;
    private detectDecoratorPattern;
    private detectObserverPattern;
    private detectStrategyPattern;
    /**
     * Quality check methods
     */
    private checkNamingConventions;
    private checkDocumentation;
    private checkCodeDuplication;
    private checkErrorHandling;
    /**
     * Helper methods for quality checks
     */
    private isBadNaming;
    private hasDocumentation;
    private findDuplicateCode;
    private generateCodeSignature;
    private hasErrorHandling;
    /**
     * Complexity calculation methods
     */
    private calculateCyclomaticComplexity;
    private calculateCognitiveComplexity;
    private analyzeCoupling;
    private analyzeCohesion;
    private calculateSharedData;
    /**
     * Security analysis methods
     */
    private detectSecurityIssues;
    private checkInputValidation;
    private detectHardcodedSecrets;
    private hasSQLInjectionRisk;
    private isInputFunction;
    private hasInputValidation;
    private hasHardcodedSecret;
    /**
     * Performance analysis methods
     */
    private detectPerformanceIssues;
    private analyzeAlgorithmComplexity;
    private analyzeMemoryUsage;
    private findNestedLoops;
    private hasNestedLoop;
    private estimateAlgorithmComplexity;
    private detectMemoryLeaks;
    /**
     * Score calculation methods
     */
    private calculateStructuralScore;
    private calculateQualityScore;
    private calculatePatternScore;
    private calculateComplexityScore;
    private calculateSecurityScore;
    private calculatePerformanceScore;
    private calculateOverallConfidence;
    private generateAnalysisExplanation;
}
//# sourceMappingURL=code-analysis-reasoning-engine.d.ts.map