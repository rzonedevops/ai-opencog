import { PatternInput, PatternResult, ReasoningQuery, ReasoningResult } from '../../common';
/**
 * Advanced pattern matching reasoning engine
 * Implements sophisticated pattern recognition and matching algorithms
 */
export declare class PatternMatchingEngine {
    /**
     * Perform pattern matching based reasoning
     */
    reason(query: ReasoningQuery): Promise<ReasoningResult>;
    /**
     * Advanced pattern recognition with multiple algorithms
     */
    recognizePatterns(input: PatternInput): Promise<PatternResult[]>;
    /**
     * Recognize structural patterns in data
     */
    private recognizeStructuralPatterns;
    /**
     * Recognize sequential patterns
     */
    private recognizeSequentialPatterns;
    /**
     * Recognize hierarchical patterns
     */
    private recognizeHierarchicalPatterns;
    /**
     * Recognize semantic patterns
     */
    private recognizeSemanticPatterns;
    /**
     * Recognize behavioral patterns
     */
    private recognizeBehavioralPatterns;
    /**
     * Group atoms by their structural properties
     */
    private groupAtomsByStructure;
    /**
     * Generate structural signature for an atom
     */
    private generateStructuralSignature;
    /**
     * Extract structural template from atom
     */
    private extractStructuralTemplate;
    /**
     * Find sequential patterns in atoms
     */
    private findSequentialPatterns;
    /**
     * Check if two atoms are sequentially related
     */
    private isSequentiallyRelated;
    /**
     * Extract transitions from sequence
     */
    private extractTransitions;
    /**
     * Identify relationship between two atoms
     */
    private identifyRelationship;
    /**
     * Build hierarchies from atoms
     */
    private buildHierarchies;
    /**
     * Build hierarchy tree starting from an atom
     */
    private buildHierarchyTree;
    /**
     * Find common hierarchical patterns
     */
    private findCommonHierarchicalPatterns;
    /**
     * Extract subtrees from hierarchy
     */
    private extractSubtrees;
    /**
     * Group similar subtrees
     */
    private groupSimilarSubtrees;
    /**
     * Check if two subtrees are similar
     */
    private areSubtreesSimilar;
    /**
     * Extract common pattern from subtree group
     */
    private extractCommonPattern;
    /**
     * Extract structure template
     */
    private extractStructureTemplate;
    /**
     * Calculate subtree depth
     */
    private calculateSubtreeDepth;
    /**
     * Cluster atoms by semantic similarity
     */
    private clusterAtomsBySemantic;
    /**
     * Check if two atoms are semantically related
     */
    private areSemanticallyRelated;
    /**
     * Calculate name similarity
     */
    private calculateNameSimilarity;
    /**
     * Check if atoms share common elements
     */
    private shareCommonElements;
    /**
     * Extract semantic pattern from cluster
     */
    private extractSemanticPattern;
    /**
     * Find most common element in array
     */
    private findMostCommonElement;
    /**
     * Extract common concept from names
     */
    private extractCommonConcept;
    /**
     * Extract common relations from cluster
     */
    private extractCommonRelations;
    /**
     * Identify behavioral patterns
     */
    private identifyBehavioralPatterns;
    /**
     * Find causal patterns
     */
    private findCausalPatterns;
    /**
     * Find feedback loops
     */
    private findFeedbackLoops;
    /**
     * Find conditional behaviors
     */
    private findConditionalBehaviors;
    /**
     * Filter and rank patterns by significance
     */
    private filterAndRankPatterns;
    /**
     * Convert patterns to atoms for reasoning result
     */
    private convertPatternsToAtoms;
    /**
     * Calculate overall confidence for patterns
     */
    private calculatePatternConfidence;
    /**
     * Extract pattern types for metadata
     */
    private extractPatternTypes;
    /**
     * Calculate various confidence metrics
     */
    private calculateStructuralConfidence;
    private calculateSequentialConfidence;
    private calculateHierarchicalConfidence;
    private calculateSemanticConfidence;
    private calculateBehavioralConfidence;
    private calculateComplexity;
    private calculateTransitionStrength;
    private calculateHierarchyDepth;
    private calculateBranchingFactor;
    private calculateHierarchicalComplexity;
    private calculateSemanticCoherence;
    private extractHierarchyInstances;
}
//# sourceMappingURL=pattern-matching-engine.d.ts.map