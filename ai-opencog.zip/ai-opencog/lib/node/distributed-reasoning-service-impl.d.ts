import { ILogger } from '@theia/core/lib/common/logger';
import { Event } from '@theia/core/lib/common/event';
import { DistributedReasoningService } from '../common/distributed-reasoning-service';
import { DistributedReasoningTask, DistributedReasoningResult, DistributedReasoningConfig, ReasoningNode, NodeRegistration, NodeHeartbeat, DistributedReasoningStats, ReasoningCapability } from '../common/distributed-reasoning-types';
import { ReasoningQuery } from '../common/opencog-types';
/**
 * Implementation of the distributed reasoning service
 */
export declare class DistributedReasoningServiceImpl implements DistributedReasoningService {
    protected readonly logger: ILogger;
    private config;
    private nodeRegistry;
    private taskQueue;
    private completedTasks;
    private heartbeatTimers;
    private readonly onNodeRegisteredEmitter;
    private readonly onNodeDeregisteredEmitter;
    private readonly onTaskCompletedEmitter;
    private readonly onTaskFailedEmitter;
    readonly onNodeRegistered: Event<{
        node: ReasoningNode;
    }>;
    readonly onNodeDeregistered: Event<{
        nodeId: string;
    }>;
    readonly onTaskCompleted: Event<{
        result: DistributedReasoningResult;
    }>;
    readonly onTaskFailed: Event<{
        taskId: string;
        error: string;
    }>;
    constructor();
    /**
     * Submit a reasoning task for distributed processing
     */
    submitTask(query: ReasoningQuery, constraints?: any): Promise<DistributedReasoningResult>;
    /**
     * Get the status of a distributed reasoning task
     */
    getTaskStatus(taskId: string): Promise<DistributedReasoningTask | undefined>;
    /**
     * Cancel a distributed reasoning task
     */
    cancelTask(taskId: string): Promise<boolean>;
    /**
     * Register a new reasoning node
     */
    registerNode(registration: NodeRegistration): Promise<string>;
    /**
     * Deregister a reasoning node
     */
    deregisterNode(nodeId: string): Promise<boolean>;
    /**
     * Send heartbeat from a reasoning node
     */
    sendHeartbeat(heartbeat: NodeHeartbeat): Promise<void>;
    /**
     * Get list of active reasoning nodes
     */
    getActiveNodes(): Promise<ReasoningNode[]>;
    /**
     * Get nodes with specific capabilities
     */
    getNodesByCapability(capability: ReasoningCapability): Promise<ReasoningNode[]>;
    /**
     * Get system statistics
     */
    getSystemStats(): Promise<DistributedReasoningStats>;
    /**
     * Update system configuration
     */
    updateConfig(config: Partial<DistributedReasoningConfig>): Promise<void>;
    /**
     * Get current system configuration
     */
    getConfig(): Promise<DistributedReasoningConfig>;
    /**
     * Perform system health check
     */
    healthCheck(): Promise<{
        healthy: boolean;
        issues?: string[];
    }>;
    private processTask;
    private selectNodesForTask;
    private executeOnNodes;
    private aggregateNodeResults;
    private applyAggregationStrategy;
    private majorityVoteAggregation;
    private weightedAverageAggregation;
    private confidenceWeightedAggregation;
    private bestResultAggregation;
    private applyLoadBalancing;
    private calculateConsensusLevel;
    private simulateNodeExecution;
    private updateNodePerformance;
    private inferRequiredCapabilities;
    private redistributeTasksFromNode;
    private startHeartbeatMonitoring;
    private startTaskProcessing;
    private checkNodeHeartbeats;
    private resetHeartbeatTimeout;
    private calculateSystemThroughput;
    private generateTaskId;
    private generateNodeId;
    private shuffleArray;
    private getDefaultConfig;
}
//# sourceMappingURL=distributed-reasoning-service-impl.d.ts.map