export {};
//# sourceMappingURL=opencog-chat-agent.spec.d.ts.map