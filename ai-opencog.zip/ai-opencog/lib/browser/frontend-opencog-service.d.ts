import { WebSocketConnectionProvider } from '@theia/core/lib/browser/messaging';
import { Atom, AtomPattern, ReasoningQuery, ReasoningResult, LearningData, PatternInput, PatternResult, OpenCogService, LearningModel, AdaptationStrategy, UserBehaviorPattern, LearningContext, UserFeedback, MultiModalData, MultiModalPatternInput, MultiModalPatternResult, MultiModalLearningData, ModalityType, TensorData } from '../common';
/**
 * Frontend OpenCog service that communicates with the backend via RPC
 */
export declare class FrontendOpenCogService implements OpenCogService {
    protected readonly connectionProvider: WebSocketConnectionProvider;
    private readonly openCogService;
    constructor(connectionProvider: WebSocketConnectionProvider);
    addAtom(atom: Atom): Promise<string>;
    queryAtoms(pattern: AtomPattern): Promise<Atom[]>;
    removeAtom(atomId: string): Promise<boolean>;
    updateAtom(atomId: string, updates: Partial<Atom>): Promise<boolean>;
    reason(query: ReasoningQuery): Promise<ReasoningResult>;
    learn(data: LearningData): Promise<void>;
    recognizePatterns(input: PatternInput): Promise<PatternResult[]>;
    getAtomSpaceSize(): Promise<number>;
    clearAtomSpace(): Promise<void>;
    exportAtomSpace(): Promise<string>;
    importAtomSpace(data: string): Promise<void>;
    learnFromFeedback(feedback: UserFeedback, context: LearningContext): Promise<void>;
    adaptToUser(userId: string, domain: string, data: any): Promise<AdaptationStrategy>;
    getAdaptationStrategy(userId: string, domain: string): Promise<AdaptationStrategy | undefined>;
    learnUserBehavior(userId: string, action: string, context: any): Promise<void>;
    getUserBehaviorPatterns(userId: string): Promise<UserBehaviorPattern[]>;
    predictUserAction(userId: string, context: any): Promise<{
        action: string;
        confidence: number;
    }[]>;
    createLearningModel(type: string, parameters?: Record<string, any>): Promise<LearningModel>;
    updateLearningModel(modelId: string, trainingData: LearningData[]): Promise<LearningModel>;
    getLearningModel(modelId: string): Promise<LearningModel | undefined>;
    listLearningModels(): Promise<LearningModel[]>;
    personalize(userId: string, preferences: Record<string, any>): Promise<void>;
    getPersonalization(userId: string): Promise<Record<string, any>>;
    getLearningStats(): Promise<{
        totalLearningRecords: number;
        modelAccuracy: Record<string, number>;
        userAdaptations: number;
        behaviorPatterns: number;
    }>;
    /**
     * Process single multi-modal data
     */
    processMultiModalData(data: MultiModalData): Promise<MultiModalData>;
    /**
     * Process batch of multi-modal data
     */
    processMultiModalBatch(data: MultiModalData[]): Promise<MultiModalData[]>;
    /**
     * Recognize patterns in multi-modal data
     */
    recognizeMultiModalPatterns(input: MultiModalPatternInput): Promise<MultiModalPatternResult[]>;
    /**
     * Learn from multi-modal data
     */
    learnFromMultiModalData(data: MultiModalLearningData): Promise<void>;
    /**
     * Get multi-modal learning statistics
     */
    getMultiModalLearningStats(): Promise<{
        totalMultiModalRecords: number;
        modalityDistribution: Record<ModalityType, number>;
        crossModalPatterns: number;
        processingAccuracy: Record<ModalityType, number>;
    }>;
    /**
     * Process tensor data with 4 degrees of freedom
     */
    processTensorData(tensor: TensorData): Promise<TensorData>;
    /**
     * Perform specific tensor operation
     */
    performTensorOperation(tensor: TensorData, operation: string, parameters?: Record<string, any>): Promise<TensorData>;
    /**
     * Fuse multiple tensor data
     */
    fuseTensorData(tensors: TensorData[], strategy?: 'concatenation' | 'addition' | 'attention' | 'learned'): Promise<TensorData>;
    /**
     * Cross-modal reasoning
     */
    reasonAcrossModalities(query: ReasoningQuery, modalData: MultiModalData[]): Promise<ReasoningResult>;
    /**
     * Analyze multi-modal context
     */
    analyzeMultiModalContext(data: MultiModalData[]): Promise<{
        context: any;
        dominantModality: ModalityType;
        modalityInteractions: Array<{
            source: ModalityType;
            target: ModalityType;
            interaction: string;
            strength: number;
        }>;
        cognitiveLoad: number;
    }>;
    /**
     * Apply attention mechanisms for multi-modal data
     */
    applyAttentionMechanism(data: MultiModalData[], attentionType: 'spatial' | 'temporal' | 'cross-modal' | 'cognitive'): Promise<{
        attentionWeights: Record<string, number>;
        focusedData: MultiModalData[];
        attentionMap?: number[];
    }>;
    getKnowledgeManagementService(): any;
}
//# sourceMappingURL=frontend-opencog-service.d.ts.map