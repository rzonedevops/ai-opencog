import { PreferenceService } from '@theia/core/lib/browser/preferences/preference-service';
import { TaskService } from '@theia/task/lib/browser/task-service';
import { DebugService } from '@theia/debug/lib/browser/debug-service';
import { ActuatorResult, Actuator } from '../common/sensor-motor-types';
/**
 * Controls development tools including editor configuration, build automation, and debugging assistance
 */
export declare class ToolControlActuator implements Actuator {
    private readonly preferenceService;
    private readonly taskService;
    private readonly debugService;
    constructor(preferenceService: PreferenceService, taskService: TaskService, debugService: DebugService);
    execute(parameters: any): Promise<ActuatorResult>;
    isAvailable(): Promise<boolean>;
    private configureEditor;
    private runBuild;
    private startDebug;
    private optimizeSettings;
    private setupAutoBuild;
    private configureLinting;
    private setupTesting;
    private getBuildCommand;
    /**
     * Get current tool configurations
     */
    getCurrentConfiguration(): Promise<Record<string, any>>;
    /**
     * Apply performance optimizations based on usage patterns
     */
    applyPerformanceOptimizations(usageData: any): Promise<ActuatorResult>;
}
//# sourceMappingURL=tool-control-actuator.d.ts.map