import { Agent, LanguageModelRequirement } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { EditorManager } from '@theia/editor/lib/browser';
import { FileService } from '@theia/filesystem/lib/browser';
import { VariableResolverService } from '@theia/variable-resolver/lib/browser';
import { OpenCogService } from '../common/opencog-service';
/**
 * User behavior data structures
 */
export interface UserBehavior {
    userId: string;
    sessionId: string;
    timestamp: number;
    action: string;
    context: Record<string, any>;
    duration?: number;
    success?: boolean;
}
export interface BehaviorAnalytics {
    totalActions: number;
    sessionDuration: number;
    mostFrequentActions: Array<{
        action: string;
        frequency: number;
    }>;
    errorRate: number;
    productivityScore: number;
    learningVelocity: number;
}
/**
 * Enhanced User Behavior Learning Agent for comprehensive behavioral analysis
 * Part of Phase 3: AI Agent Enhancement in the SKZ Integration workflow
 */
export declare class UserBehaviorLearningAgent implements Agent {
    private readonly openCogService;
    private readonly workspaceService;
    private readonly editorManager;
    private readonly fileService;
    private readonly variableService;
    readonly id = "user-behavior-learning";
    readonly name = "User Behavior Learning";
    readonly description = "Learns from user interactions to improve IDE experience and provide personalized assistance";
    readonly variables: string[];
    readonly functions: string[];
    readonly prompts: {
        id: string;
        content: string;
    }[];
    private userSessions;
    private behaviorAnalytics;
    private activeSessionId;
    private sessionStartTime;
    constructor(openCogService: OpenCogService, workspaceService: WorkspaceService, editorManager: EditorManager, fileService: FileService, variableService: VariableResolverService);
    protected init(): void;
    /**
     * Track user behavior from various IDE interactions
     */
    trackUserBehavior(userId: string, action: string, context: Record<string, any>, duration?: number, success?: boolean): Promise<void>;
    /**
     * Learn user preferences from repeated behaviors
     */
    learnUserPreferences(userId: string): Promise<Record<string, any>>;
    /**
     * Get behavior-based recommendations for the user
     */
    getBehaviorRecommendations(userId: string): Promise<Array<{
        type: string;
        recommendation: string;
        confidence: number;
    }>>;
    /**
     * Adapt the IDE interface based on learned behaviors
     */
    adaptInterfaceForUser(userId: string): Promise<Record<string, any>>;
    /**
     * Get comprehensive behavior analytics for a user
     */
    getBehaviorAnalytics(userId: string): Promise<BehaviorAnalytics>;
    /**
     * Provide feedback on AI assistance based on user behavior
     */
    provideBehavioralFeedback(userId: string, assistanceType: string, wasHelpful: boolean, context: Record<string, any>): Promise<void>;
    private learnFromBehavior;
    private updateBehaviorAnalytics;
    private predictNextUserAction;
    private startBehaviorTracking;
    private generateSessionId;
    private extractFileTypes;
    private getFrequentCommands;
    private analyzeTimingPatterns;
    private analyzeErrorPatterns;
    private identifyWorkflowOptimizations;
    private calculateAnalytics;
    private calculateLearningVelocity;
    languageModelRequirements: LanguageModelRequirement[];
}
//# sourceMappingURL=user-behavior-learning-agent.d.ts.map