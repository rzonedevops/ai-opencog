import { Disposable } from '@theia/core/lib/common/disposable';
import { ITextModel } from '@theia/monaco-editor-core/esm/vs/editor/common/model';
import { OpenCogService } from '../common/opencog-service';
import { IntelligentRefactoringProvider, CodeQualityIssue } from './intelligent-refactoring';
import { PatternRecognitionAgent } from './pattern-recognition-agent';
import { Event } from '@theia/core/lib/common/event';
export interface AnalysisResult {
    fileUri: string;
    timestamp: number;
    qualityMetrics: {
        score: number;
        complexity: number;
        maintainability: number;
        performance: number;
    };
    issues: CodeQualityIssue[];
    recommendations: string[];
    patterns: any[];
}
export interface PerformanceOptimization {
    id: string;
    title: string;
    description: string;
    impact: 'low' | 'medium' | 'high';
    category: 'memory' | 'cpu' | 'io' | 'algorithm';
    suggestion: string;
    confidence: number;
}
/**
 * Real-time Code Analysis service providing continuous code quality monitoring,
 * issue detection and suggestions, and performance optimization recommendations
 */
export declare class RealTimeCodeAnalyzer implements Disposable {
    private readonly opencog;
    private readonly refactoringProvider;
    private readonly patternAgent;
    private readonly disposables;
    private readonly analysisQueue;
    private readonly analysisResults;
    private readonly onAnalysisCompletedEmitter;
    readonly onAnalysisCompleted: Event<AnalysisResult>;
    private readonly onIssuesDetectedEmitter;
    readonly onIssuesDetected: Event<{
        fileUri: string;
        issues: CodeQualityIssue[];
    }>;
    constructor(opencog: OpenCogService, refactoringProvider: IntelligentRefactoringProvider, patternAgent: PatternRecognitionAgent);
    /**
     * Start continuous monitoring of a text model
     */
    startMonitoring(model: ITextModel): void;
    /**
     * Stop monitoring a specific model
     */
    stopMonitoring(uri: string): void;
    /**
     * Get the latest analysis result for a file
     */
    getAnalysisResult(uri: string): AnalysisResult | undefined;
    /**
     * Perform immediate analysis of a model
     */
    analyzeImmediately(model: ITextModel): Promise<AnalysisResult>;
    /**
     * Generate performance optimization recommendations
     */
    getPerformanceOptimizations(model: ITextModel): Promise<PerformanceOptimization[]>;
    private scheduleAnalysis;
    private performAnalysis;
    private calculateQualityMetrics;
    private calculateComplexityScore;
    private calculateMaintainabilityScore;
    private calculatePerformanceScore;
    private generateRecommendations;
    private detectAlgorithmicIssues;
    private detectMemoryIssues;
    private detectIOIssues;
    private detectCPUIntensiveOperations;
    private detectLanguage;
    dispose(): void;
}
//# sourceMappingURL=real-time-analyzer.d.ts.map