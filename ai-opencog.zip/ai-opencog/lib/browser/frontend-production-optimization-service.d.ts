import { WebSocketConnectionProvider } from '@theia/core/lib/browser/messaging';
import { Event } from '@theia/core/lib/common/event';
import { ProductionOptimizationService, ProductionMetrics, SystemHealth, ProductionStats, OptimizationResult, AlertConfig, AlertEvent, CacheMetrics, ProductionConfig } from '../common';
export declare class FrontendProductionOptimizationService implements ProductionOptimizationService {
    private service;
    private readonly onPerformanceAlertEmitter;
    private readonly onHealthChangedEmitter;
    private readonly onOptimizationAppliedEmitter;
    private readonly onMetricsCollectedEmitter;
    readonly onPerformanceAlert: Event<AlertEvent>;
    readonly onHealthChanged: Event<SystemHealth>;
    readonly onOptimizationApplied: Event<OptimizationResult>;
    readonly onMetricsCollected: Event<ProductionMetrics>;
    constructor(connectionProvider: WebSocketConnectionProvider);
    getMetrics(): Promise<ProductionMetrics>;
    getHealth(): Promise<SystemHealth>;
    getStats(): Promise<ProductionStats>;
    startMonitoring(): Promise<void>;
    stopMonitoring(): Promise<void>;
    optimizePerformance(type: string): Promise<OptimizationResult>;
    configureAlerts(alerts: AlertConfig[]): Promise<void>;
    getCacheMetrics(): Promise<CacheMetrics>;
    clearCache(pattern?: string): Promise<void>;
    exportMetrics(format: 'json' | 'csv', timeRange?: {
        start: number;
        end: number;
    }): Promise<string>;
    getConfig(): Promise<ProductionConfig>;
    updateConfig(config: Partial<ProductionConfig>): Promise<void>;
    healthCheck(): Promise<SystemHealth>;
    forceGarbageCollection(): Promise<void>;
    optimizeMemory(): Promise<OptimizationResult>;
    getResourceHistory(hours: number): Promise<ProductionMetrics[]>;
}
//# sourceMappingURL=frontend-production-optimization-service.d.ts.map