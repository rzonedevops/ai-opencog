import { Agent } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { MessageService } from '@theia/core';
import { OpenCogService, KnowledgeManagementService } from '../common';
export interface ProblemContext {
    id: string;
    title: string;
    description: string;
    domain: 'architecture' | 'performance' | 'security' | 'debugging' | 'design' | 'integration' | 'scalability';
    complexity: 'low' | 'medium' | 'high' | 'expert';
    constraints: string[];
    goals: string[];
    currentSolution?: string;
    previousAttempts?: Array<{
        approach: string;
        result: string;
        reasoning: string;
        success: boolean;
    }>;
    context: {
        codebase?: string;
        technology?: string[];
        timeline?: string;
        resources?: string[];
    };
}
export interface ReasoningSolution {
    id: string;
    approach: string;
    reasoning: {
        type: 'deductive' | 'inductive' | 'abductive' | 'analogical' | 'creative';
        steps: Array<{
            step: number;
            description: string;
            reasoning: string;
            confidence: number;
            dependencies?: string[];
        }>;
        conclusion: string;
        alternatives: Array<{
            approach: string;
            pros: string[];
            cons: string[];
            feasibility: number;
        }>;
    };
    implementation: {
        phases: Array<{
            phase: string;
            tasks: string[];
            estimatedTime: string;
            dependencies: string[];
            risks: string[];
        }>;
        codeExamples?: string[];
        architecturalChanges?: string[];
        testingStrategy?: string;
    };
    validation: {
        successCriteria: string[];
        testCases: string[];
        metrics: string[];
        rollbackPlan: string;
    };
    confidence: number;
    learningNotes: string[];
}
/**
 * Advanced Reasoning Agent for Complex Problem-Solving
 *
 * This agent specializes in:
 * - Multi-step reasoning for complex software engineering problems
 * - Architecture decision making with cognitive analysis
 * - Creative problem-solving using analogical reasoning
 * - Learning from problem-solving patterns and outcomes
 * - Collaborative reasoning with team knowledge integration
 */
export declare class AdvancedReasoningAgent extends Agent {
    private readonly openCogService;
    private readonly knowledgeService;
    private readonly workspaceService;
    private readonly messageService;
    private problemSolvingHistory;
    private reasoningPatterns;
    private solutionEffectiveness;
    constructor(openCogService: OpenCogService, knowledgeService: KnowledgeManagementService, workspaceService: WorkspaceService, messageService: MessageService);
    private initializeReasoningCapabilities;
    private initializeProblemSolvingKnowledge;
    private seedProblemSolvingKnowledge;
    private loadReasoningPatterns;
    private initializeSolutionTracking;
    /**
     * Solve complex problems using advanced cognitive reasoning
     */
    solveComplexProblem(problem: ProblemContext): Promise<ReasoningSolution>;
    private analyzeComplexProblem;
    private generateReasoningApproaches;
    private selectOptimalApproach;
    private performAdvancedReasoning;
    private performDeductiveReasoning;
    private performInductiveReasoning;
    private performAbductiveReasoning;
    private performAnalogicalReasoning;
    private performCreativeReasoning;
    private performDefaultReasoning;
    private generateImplementationPlan;
    private createValidationStrategy;
    private generateLearningInsights;
    private calculateSolutionConfidence;
    private learnFromReasoning;
    private generateFallbackSolution;
    private convertProblemToAtoms;
    private discoverRelatedKnowledge;
    private findSimilarProblems;
    private analyzeConstraints;
    private analyzeDomainContext;
    private calculateApproachSuitability;
    private identifyRelevantPrinciples;
    private deriveLogicalConclusions;
    private extractPatternsFromSimilarProblems;
    private generalizePatternToCurrentProblem;
    private generatePatternAlternatives;
    private generateProblemHypotheses;
    private generateHypothesisBasedSolution;
    private generateAlternativeHypothesisSolutions;
    private identifyNecessaryAdaptations;
    private adaptSolutionFromAnalogy;
    private generateAnalogicalAlternatives;
    private generateCreativeApproaches;
    private synthesizeCreativeSolution;
    private generateCodeExamples;
    private identifyArchitecturalChanges;
    private createTestingStrategy;
    private storeProblemInHistory;
}
//# sourceMappingURL=advanced-reasoning-agent.d.ts.map