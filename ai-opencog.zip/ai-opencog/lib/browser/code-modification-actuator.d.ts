import { EditorManager } from '@theia/editor/lib/browser/editor-manager';
import { FileService } from '@theia/filesystem/lib/browser/file-service';
import { Workspace } from '@theia/workspace/lib/browser/workspace-service';
import { RefactoringOperation, ActuatorResult, Actuator } from '../common/sensor-motor-types';
/**
 * Executes code modification operations including refactoring and automated code changes
 */
export declare class CodeModificationActuator implements Actuator {
    private readonly editorManager;
    private readonly fileService;
    private readonly workspace;
    constructor(editorManager: EditorManager, fileService: FileService, workspace: Workspace);
    execute(parameters: RefactoringOperation): Promise<ActuatorResult>;
    isAvailable(): Promise<boolean>;
    private performRename;
    private performExtractMethod;
    private performInline;
    private performMove;
    private performChangeSignature;
    private renameInFile;
    private renameInWorkspace;
    private findFilesInDirectory;
    private isTextFile;
    private getOrOpenEditor;
    private detectMethodParameters;
    private generateExtractedMethod;
    private applyExtractMethod;
    private findMethodInsertionPoint;
    private escapeRegExp;
}
//# sourceMappingURL=code-modification-actuator.d.ts.map