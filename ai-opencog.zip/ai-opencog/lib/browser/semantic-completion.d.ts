import { CompletionProvider, CompletionContext, Position } from '@theia/monaco-editor-core/esm/vs/editor/common/languages';
import { ITextModel } from '@theia/monaco-editor-core/esm/vs/editor/common/model';
import { CompletionList } from '@theia/monaco-editor-core/esm/vs/editor/common/languages';
import { OpenCogService } from '../common/opencog-service';
/**
 * Semantic Code Completion Provider using OpenCog reasoning
 * as specified in Phase 2 requirements
 */
export declare class SemanticCompletionProvider implements CompletionProvider {
    private opencog;
    constructor(opencog: OpenCogService);
    provideCompletionItems(model: ITextModel, position: Position, context: CompletionContext): Promise<CompletionList>;
    private extractContext;
    private extractSemanticAtoms;
    private detectCurrentContext;
    private getIndentLevel;
    private getLanguageFromModel;
    private convertToCompletionItems;
    private getCompletionKind;
    private generateContextAwareSuggestions;
    private generateSemanticPatternSuggestions;
    private findCommonPatterns;
}
//# sourceMappingURL=semantic-completion.d.ts.map