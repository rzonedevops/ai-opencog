export {};
//# sourceMappingURL=sensor-motor-system.spec.d.ts.map