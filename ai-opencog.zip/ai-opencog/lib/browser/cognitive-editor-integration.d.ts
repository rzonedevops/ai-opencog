import { Disposable } from '@theia/core/lib/common/disposable';
import { EditorManager } from '@theia/editor/lib/browser/editor-manager';
import { PatternRecognitionAgent } from './pattern-recognition-agent';
import { LearningAgent } from './enhanced-learning-agent';
import { SemanticCompletionProvider } from './semantic-completion';
import { IntelligentRefactoringProvider } from './intelligent-refactoring';
import { RealTimeCodeAnalyzer } from './real-time-analyzer';
import { CodeAnalysisAgent } from './code-analysis-agent';
/**
 * Phase 2 Editor Integration Service
 * Integrates all cognitive capabilities into the code editing experience
 */
export declare class CognitiveEditorIntegration implements Disposable {
    private readonly editorManager;
    private readonly patternAgent;
    private readonly learningAgent;
    private readonly semanticCompletion;
    private readonly refactoringProvider;
    private readonly realTimeAnalyzer;
    private readonly codeAnalysisAgent;
    private readonly disposables;
    private readonly editorAnalyzers;
    constructor(editorManager: EditorManager, patternAgent: PatternRecognitionAgent, learningAgent: LearningAgent, semanticCompletion: SemanticCompletionProvider, refactoringProvider: IntelligentRefactoringProvider, realTimeAnalyzer: RealTimeCodeAnalyzer, codeAnalysisAgent: CodeAnalysisAgent);
    init(): void;
    private setupEditorIntegration;
    private integrateWithEditor;
    private registerCompletionProvider;
    private setupCodeActionProvider;
    private setupHoverProvider;
    private setupDiagnosticsProvider;
    private setupLearningIntegration;
    private setupRealTimeAnalysis;
    private severityToMarkerSeverity;
    /**
     * Get cognitive insights for a specific file
     */
    getCognitiveInsights(fileUri: string): Promise<any>;
    /**
     * Apply cognitive refactoring suggestion
     */
    applyCognitiveRefactoring(suggestionId: string, fileUri: string): Promise<boolean>;
    dispose(): void;
}
//# sourceMappingURL=cognitive-editor-integration.d.ts.map