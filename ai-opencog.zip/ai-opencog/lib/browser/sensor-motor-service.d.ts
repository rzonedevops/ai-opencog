import { Disposable } from '@theia/core/lib/common/disposable';
import { OpenCogService } from '../common/opencog-service';
import { CodeChangeSensor } from './code-change-sensor';
import { ActivitySensor } from './activity-sensor';
import { EnvironmentSensor } from './environment-sensor';
import { CodeModificationActuator } from './code-modification-actuator';
import { ToolControlActuator } from './tool-control-actuator';
import { EnvironmentManagementActuator } from './environment-management-actuator';
import { Sensor, Actuator, ActuatorResult } from '../common/sensor-motor-types';
/**
 * Coordinates the sensor-motor system, managing sensors that feed data to OpenCog
 * and actuators that respond to cognitive reasoning results
 */
export declare class SensorMotorService implements Disposable {
    private readonly opencog;
    private readonly codeChangeSensor;
    private readonly activitySensor;
    private readonly environmentSensor;
    private readonly codeModificationActuator;
    private readonly toolControlActuator;
    private readonly environmentManagementActuator;
    protected disposables: any;
    protected active: boolean;
    protected sensors: Sensor[];
    protected actuators: Map<string, Actuator>;
    constructor(opencog: OpenCogService, codeChangeSensor: CodeChangeSensor, activitySensor: ActivitySensor, environmentSensor: EnvironmentSensor, codeModificationActuator: CodeModificationActuator, toolControlActuator: ToolControlActuator, environmentManagementActuator: EnvironmentManagementActuator);
    protected init(): void;
    /**
     * Start the sensor-motor system
     */
    start(): Promise<void>;
    /**
     * Stop the sensor-motor system
     */
    stop(): Promise<void>;
    /**
     * Check if the system is active
     */
    isActive(): boolean;
    dispose(): void;
    /**
     * Execute an actuator action
     */
    executeActuator(actuatorType: string, parameters: any): Promise<ActuatorResult>;
    /**
     * Get sensor statistics
     */
    getSensorStats(): Record<string, any>;
    /**
     * Get recent sensor data for analysis
     */
    getRecentSensorData(): any;
    private startCognitiveMotorLoop;
    private processCognitiveMotorCycle;
    private generateReasoningQueries;
    private processReasoningResult;
    private handlePerformanceOptimization;
    private handleCodeQualityImprovements;
    private handleWorkflowOptimization;
    /**
     * Trigger manual actuator based on OpenCog reasoning
     */
    triggerCognitiveActuation(reasoning: any): Promise<ActuatorResult[]>;
}
//# sourceMappingURL=sensor-motor-service.d.ts.map