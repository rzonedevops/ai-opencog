import { Agent } from '@theia/ai-core/lib/common/agent';
import { OpenCogService } from '../common/opencog-service';
import { PatternResult } from '../common/opencog-types';
/**
 * Pattern Recognition Agent for code pattern detection,
 * behavioral pattern analysis, and project evolution tracking
 */
export declare class PatternRecognitionAgent extends Agent {
    private readonly opencog;
    constructor(opencog: OpenCogService);
    /**
     * Detect code patterns in source code
     */
    detectCodePatterns(code: string, fileUri: string): Promise<PatternResult[]>;
    /**
     * Analyze behavioral patterns in development workflow
     */
    analyzeBehavioralPatterns(actions: Array<{
        action: string;
        timestamp: number;
        context: any;
    }>): Promise<PatternResult[]>;
    /**
     * Track project evolution patterns over time
     */
    trackProjectEvolution(commitHistory: Array<{
        hash: string;
        message: string;
        timestamp: number;
        files: string[];
    }>): Promise<PatternResult[]>;
    /**
     * Generate pattern-based recommendations
     */
    generatePatternRecommendations(patterns: PatternResult[]): Promise<string[]>;
    private detectLanguage;
    private calculateTimespan;
    private calculateCommitTimespan;
    private prepareEvolutionData;
    private extractMessagePatterns;
    private calculateFileChangeFrequency;
}
//# sourceMappingURL=pattern-recognition-agent.d.ts.map