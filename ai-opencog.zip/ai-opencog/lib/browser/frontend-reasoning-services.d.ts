import { WebSocketConnectionProvider } from '@theia/core/lib/browser/messaging';
import { DeductiveReasoningService, CodeLogicResult, ReasoningResult, InductiveReasoningService, PatternGeneralizationInput, PatternGeneralizationResult, AbductiveReasoningService, GeneratedHypothesis } from '../common/reasoning-services';
/**
 * Frontend proxy for DeductiveReasoningService
 */
export declare class FrontendDeductiveReasoningService implements DeductiveReasoningService {
    private readonly service;
    constructor(connectionProvider: WebSocketConnectionProvider);
    verifyCodeLogic(code: string): Promise<CodeLogicResult>;
    deduceConclusions(premises: any[]): Promise<ReasoningResult>;
    checkConsistency(statements: any[]): Promise<{
        isConsistent: boolean;
        conflicts?: any[];
    }>;
}
/**
 * Frontend proxy for InductiveReasoningService
 */
export declare class FrontendInductiveReasoningService implements InductiveReasoningService {
    private readonly service;
    constructor(connectionProvider: WebSocketConnectionProvider);
    generalizeFromExamples(input: PatternGeneralizationInput): Promise<PatternGeneralizationResult>;
    generateCodeFromPatterns(patterns: any[], context?: string): Promise<{
        code: string;
        confidence: number;
    }>;
    identifyBestPractices(examples: any[]): Promise<{
        practices: string[];
        confidence: number;
    }>;
}
/**
 * Frontend proxy for AbductiveReasoningService
 */
export declare class FrontendAbductiveReasoningService implements AbductiveReasoningService {
    private readonly service;
    constructor(connectionProvider: WebSocketConnectionProvider);
    generateBugHypotheses(symptoms: any[]): Promise<GeneratedHypothesis[]>;
    suggestCreativeSolutions(problem: string, constraints?: any[]): Promise<{
        solutions: string[];
        creativity: number;
    }>;
    proposeArchitectureOptimizations(architecture: any): Promise<{
        optimizations: any[];
        impact: number;
    }>;
}
//# sourceMappingURL=frontend-reasoning-services.d.ts.map