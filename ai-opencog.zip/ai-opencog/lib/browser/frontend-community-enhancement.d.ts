import { CommunityEnhancementService, EnhancementRequest, CommunityContribution } from '../common/community-enhancement';
/**
 * Frontend implementation of CommunityEnhancementService with UI integration
 */
export declare class FrontendCommunityEnhancementService extends CommunityEnhancementService {
    /**
     * Submit enhancement with UI validation
     */
    submitEnhancementWithValidation(request: Omit<EnhancementRequest, 'id' | 'submittedAt' | 'votes' | 'feedback' | 'status'>): Promise<string>;
    /**
     * Submit contribution with file validation
     */
    submitContributionWithValidation(contribution: Omit<CommunityContribution, 'id' | 'submittedAt' | 'status' | 'reviewComments'>, files?: File[]): Promise<string>;
    /**
     * Get enhanced community statistics with UI formatting
     */
    getFormattedCommunityStats(): {
        summary: string;
        details: {
            enhancements: {
                label: string;
                value: string;
                trend: 'up' | 'down' | 'stable';
            }[];
            contributions: {
                label: string;
                value: string;
                trend: 'up' | 'down' | 'stable';
            }[];
            engagement: {
                label: string;
                value: string;
                trend: 'up' | 'down' | 'stable';
            }[];
        };
    };
    /**
     * Get roadmap data for UI visualization
     */
    getVisualizationData(): {
        timeline: Array<{
            date: string;
            version: string;
            features: number;
            improvements: number;
        }>;
        categoryDistribution: Array<{
            category: string;
            count: number;
            percentage: number;
        }>;
        priorityMatrix: Array<{
            priority: string;
            count: number;
            averageVotes: number;
        }>;
    };
    private uploadContributionFiles;
    private showNotification;
}
//# sourceMappingURL=frontend-community-enhancement.d.ts.map