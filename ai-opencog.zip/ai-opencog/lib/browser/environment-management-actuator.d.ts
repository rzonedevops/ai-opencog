import { PreferenceService } from '@theia/core/lib/browser/preferences/preference-service';
import { ActuatorResult, Actuator } from '../common/sensor-motor-types';
/**
 * Manages development environment including resource allocation, service configuration, and performance tuning
 */
export declare class EnvironmentManagementActuator implements Actuator {
    private readonly preferenceService;
    private readonly defaultResourceLimits;
    constructor(preferenceService: PreferenceService);
    execute(parameters: any): Promise<ActuatorResult>;
    isAvailable(): Promise<boolean>;
    private allocateResources;
    private configureService;
    private optimizePerformance;
    private manageCache;
    private adjustConcurrency;
    private setupResourceMonitoring;
    private cleanupEnvironment;
    private applyPrioritySettings;
    private configureTypeScriptService;
    private configureESLintService;
    private configureFileWatcherService;
    private configureAutoCompletionService;
    private configureGitService;
}
//# sourceMappingURL=environment-management-actuator.d.ts.map