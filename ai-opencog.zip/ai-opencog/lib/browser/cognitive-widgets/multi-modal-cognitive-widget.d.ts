/// <reference types="react" />
import { ReactWidget } from '@theia/core/lib/browser/widgets/react-widget';
import { OpenCogService } from '../../common';
import * as React from '@theia/core/shared/react';
/**
 * Multi-Modal Cognitive Processing Widget for Phase 5 advanced features.
 * Provides interface for processing text, image, audio, and tensor data with 4 DoF.
 */
export declare class MultiModalCognitiveWidget extends ReactWidget {
    static readonly ID = "multi-modal-cognitive-widget";
    static readonly LABEL = "Multi-Modal Cognitive Processing";
    protected readonly toDispose: any;
    protected readonly openCogService: OpenCogService;
    protected init(): void;
    protected onCloseRequest(): void;
    protected render(): React.ReactNode;
}
//# sourceMappingURL=multi-modal-cognitive-widget.d.ts.map