export {};
//# sourceMappingURL=cognitive-widgets.spec.d.ts.map