/**
 * Phase 4: Frontend Integration - Cognitive Visualization Components
 *
 * This module exports all cognitive visualization widgets that integrate with
 * the existing OpenCog services to provide rich, interactive user interfaces
 * for cognitive development assistance.
 */
export * from './code-intelligence-widget';
export * from './learning-progress-widget';
export * from './knowledge-explorer-widget';
export * from './cognitive-assistant-widget';
export * from './cognitive-widgets-contribution';
//# sourceMappingURL=index.d.ts.map