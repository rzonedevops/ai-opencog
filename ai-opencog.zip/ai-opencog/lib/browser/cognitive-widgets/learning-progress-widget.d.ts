/// <reference types="react" />
import { BaseWidget, Message } from '@theia/core/lib/browser';
import { UserBehaviorLearningAgent } from '../user-behavior-learning-agent';
import { LearningAgent } from '../enhanced-learning-agent';
import { OpenCogService } from '../../common/opencog-service';
import * as React from '@theia/core/shared/react';
export interface LearningProgressData {
    overallProgress: number;
    learningAreas: Array<{
        name: string;
        progress: number;
        confidence: number;
        lastUpdated: string;
        category: 'coding' | 'behavior' | 'patterns' | 'preferences';
    }>;
    recentLearnings: Array<{
        timestamp: string;
        description: string;
        impact: 'high' | 'medium' | 'low';
        category: string;
    }>;
    adaptationStrategies: Array<{
        name: string;
        description: string;
        effectiveness: number;
        active: boolean;
    }>;
    learningStats: {
        totalInteractions: number;
        patternsLearned: number;
        adaptationsMade: number;
        accuracyImprovement: number;
    };
}
export declare class LearningProgressWidget extends BaseWidget {
    static readonly ID = "cognitive.learning-progress";
    static readonly LABEL: any;
    protected readonly userBehaviorAgent: UserBehaviorLearningAgent;
    protected readonly learningAgent: LearningAgent;
    protected readonly openCogService: OpenCogService;
    protected readonly toDispose: any;
    protected data: LearningProgressData | undefined;
    private updateInterval;
    protected init(): void;
    protected onActivateRequest(msg: Message): void;
    protected startPeriodicUpdates(): void;
    protected refreshLearningData(): Promise<void>;
    protected render(): React.ReactNode;
    dispose(): void;
}
//# sourceMappingURL=learning-progress-widget.d.ts.map