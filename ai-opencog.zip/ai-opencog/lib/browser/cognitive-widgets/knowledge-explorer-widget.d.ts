/// <reference types="react" />
import { BaseWidget, Message } from '@theia/core/lib/browser';
import { KnowledgeManagementService } from '../../common/knowledge-management-service';
import { OpenCogService } from '../../common/opencog-service';
import * as React from '@theia/core/shared/react';
export interface KnowledgeNode {
    id: string;
    name: string;
    type: 'concept' | 'relationship' | 'pattern' | 'file' | 'function' | 'class';
    strength: number;
    confidence: number;
    connections: string[];
    properties: Record<string, any>;
    description?: string;
}
export interface KnowledgeGraph {
    nodes: KnowledgeNode[];
    relationships: Array<{
        from: string;
        to: string;
        type: string;
        strength: number;
    }>;
}
export interface QueryResult {
    query: string;
    results: KnowledgeNode[];
    relevanceScore: number;
    timestamp: string;
}
export declare class KnowledgeExplorerWidget extends BaseWidget {
    static readonly ID = "cognitive.knowledge-explorer";
    static readonly LABEL: any;
    protected readonly knowledgeService: KnowledgeManagementService;
    protected readonly openCogService: OpenCogService;
    protected readonly toDispose: any;
    protected knowledgeGraph: KnowledgeGraph | undefined;
    protected selectedNode: KnowledgeNode | undefined;
    protected searchQuery: string;
    protected queryResults: QueryResult[];
    protected viewMode: 'graph' | 'list' | 'search';
    protected init(): void;
    protected onActivateRequest(msg: Message): void;
    protected loadKnowledgeGraph(): Promise<void>;
    protected searchKnowledge(query: string): Promise<void>;
    protected selectNode(node: KnowledgeNode): void;
    protected getNodeIcon(type: string): string;
    protected getStrengthColor(strength: number): string;
    protected render(): React.ReactNode;
    protected renderGraphView(): React.ReactNode;
    protected renderListView(): React.ReactNode;
    protected renderSearchView(): React.ReactNode;
    protected renderNodeDetails(): React.ReactNode;
    dispose(): void;
}
//# sourceMappingURL=knowledge-explorer-widget.d.ts.map