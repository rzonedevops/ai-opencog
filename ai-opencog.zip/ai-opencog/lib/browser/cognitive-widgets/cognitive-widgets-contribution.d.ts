import { AbstractViewContribution, FrontendApplication } from '@theia/core/lib/browser';
import { CommandRegistry } from '@theia/core/lib/common/command';
import { MenuModelRegistry } from '@theia/core/lib/common/menu';
import { CodeIntelligenceWidget } from './code-intelligence-widget';
import { LearningProgressWidget } from './learning-progress-widget';
import { KnowledgeExplorerWidget } from './knowledge-explorer-widget';
import { CognitiveAssistantWidget } from './cognitive-assistant-widget';
import { MultiModalCognitiveWidget } from './multi-modal-cognitive-widget';
export declare const COGNITIVE_WIDGETS_COMMANDS: {
    SHOW_CODE_INTELLIGENCE: any;
    SHOW_LEARNING_PROGRESS: any;
    SHOW_KNOWLEDGE_EXPLORER: any;
    SHOW_COGNITIVE_ASSISTANT: any;
    SHOW_MULTI_MODAL_COGNITIVE: any;
    TOGGLE_ALL_COGNITIVE_WIDGETS: any;
};
export declare class CognitiveWidgetsContribution extends AbstractViewContribution<CodeIntelligenceWidget> {
    constructor();
    protected init(): void;
    registerCommands(commands: CommandRegistry): void;
    registerMenus(menus: MenuModelRegistry): void;
    initializeLayout(app: FrontendApplication): Promise<void>;
}
export declare class LearningProgressContribution extends AbstractViewContribution<LearningProgressWidget> {
    constructor();
}
export declare class KnowledgeExplorerContribution extends AbstractViewContribution<KnowledgeExplorerWidget> {
    constructor();
}
export declare class CognitiveAssistantContribution extends AbstractViewContribution<CognitiveAssistantWidget> {
    constructor();
}
export declare class MultiModalCognitiveContribution extends AbstractViewContribution<MultiModalCognitiveWidget> {
    constructor();
}
//# sourceMappingURL=cognitive-widgets-contribution.d.ts.map