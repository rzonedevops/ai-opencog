/// <reference types="react" />
import { BaseWidget, Message } from '@theia/core/lib/browser';
import { EditorManager } from '@theia/editor/lib/browser/editor-manager';
import { IntelligentAssistanceAgent } from '../intelligent-assistance-agent';
import { OpenCogService } from '../../common/opencog-service';
import * as React from '@theia/core/shared/react';
export interface ChatMessage {
    id: string;
    type: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: string;
    reasoning?: {
        confidence: number;
        sources: string[];
        cognitiveProcess: string;
    };
    suggestions?: Array<{
        text: string;
        action: string;
        confidence: number;
    }>;
}
export interface AssistantContext {
    currentFile?: string;
    selectedText?: string;
    workspaceContext?: string;
    recentActivity?: string[];
    userPreferences?: Record<string, any>;
}
export declare class CognitiveAssistantWidget extends BaseWidget {
    static readonly ID = "cognitive.assistant";
    static readonly LABEL: any;
    protected readonly assistantAgent: IntelligentAssistanceAgent;
    protected readonly openCogService: OpenCogService;
    protected readonly editorManager: EditorManager;
    protected readonly toDispose: any;
    protected messages: ChatMessage[];
    protected currentInput: string;
    protected isProcessing: boolean;
    protected context: AssistantContext;
    private inputRef;
    protected init(): void;
    protected onActivateRequest(msg: Message): void;
    protected initializeChat(): void;
    protected handleUserInput(): Promise<void>;
    protected generateAssistantResponse(userInput: string): Promise<ChatMessage>;
    protected getCognitiveResponses(input: string): Array<{
        content: string;
        reasoning: ChatMessage['reasoning'];
        suggestions: ChatMessage['suggestions'];
    }>;
    protected handleSuggestionClick(suggestion: {
        text: string;
        action: string;
        confidence: number;
    }): void;
    protected focusInput(): void;
    protected handleKeyDown(event: React.KeyboardEvent): void;
    protected render(): React.ReactNode;
    protected getMessageIcon(type: string): string;
    private setupRealTimeContextUpdates;
    private updateCurrentContext;
    private detectFramework;
    dispose(): void;
}
//# sourceMappingURL=cognitive-assistant-widget.d.ts.map