/// <reference types="react" />
import { BaseWidget, Message } from '@theia/core/lib/browser';
import { RealTimeCodeAnalyzer, AnalysisResult } from '../real-time-analyzer';
import { OpenCogService } from '../../common/opencog-service';
import * as React from '@theia/core/shared/react';
export interface CodeIntelligenceData {
    qualityScore: number;
    complexity: number;
    maintainability: number;
    performance: number;
    issues: Array<{
        type: string;
        severity: 'error' | 'warning' | 'info';
        message: string;
        line?: number;
    }>;
    recommendations: string[];
    patterns: Array<{
        name: string;
        confidence: number;
        description: string;
    }>;
}
export declare class CodeIntelligenceWidget extends BaseWidget {
    static readonly ID = "cognitive.code-intelligence";
    static readonly LABEL: any;
    protected readonly realTimeAnalyzer: RealTimeCodeAnalyzer;
    protected readonly openCogService: OpenCogService;
    protected readonly toDispose: any;
    protected data: CodeIntelligenceData | undefined;
    protected init(): void;
    protected onActivateRequest(msg: Message): void;
    protected updateData(analysisResult: AnalysisResult): void;
    protected render(): React.ReactNode;
    protected getQualityClass(score: number): string;
    protected getComplexityClass(complexity: number): string;
    protected getIssueIcon(severity: string): string;
    dispose(): void;
}
//# sourceMappingURL=code-intelligence-widget.d.ts.map