import { CommandContribution, CommandRegistry, MenuContribution, MenuModelRegistry } from '@theia/core/lib/common';
import { ApplicationShell, WidgetManager } from '@theia/core/lib/browser';
export declare namespace ProductionCommands {
    const OPEN_PRODUCTION_MONITORING: {
        id: string;
        label: string;
    };
}
export declare class ProductionMonitoringContribution implements CommandContribution, MenuContribution {
    protected readonly shell: ApplicationShell;
    protected readonly widgetManager: WidgetManager;
    registerCommands(commands: CommandRegistry): void;
    registerMenus(menus: MenuModelRegistry): void;
    protected openProductionMonitoring(): Promise<void>;
}
//# sourceMappingURL=production-monitoring-contribution.d.ts.map