import { FileService } from '@theia/filesystem/lib/browser/file-service';
import { Disposable } from '@theia/core/lib/common/disposable';
import { OpenCogService } from '../common/opencog-service';
import { Sensor } from '../common/sensor-motor-types';
/**
 * Monitors code changes and extracts atoms for OpenCog analysis
 */
export declare class CodeChangeSensor implements Sensor, Disposable {
    private readonly fileService;
    private readonly opencog;
    protected disposables: any;
    protected active: boolean;
    constructor(fileService: FileService, opencog: OpenCogService);
    start(): Promise<void>;
    stop(): Promise<void>;
    isActive(): boolean;
    dispose(): void;
    private handleFileChanges;
    private convertToFileChange;
    private detectLanguage;
    private extractChangeAtoms;
    private extractCodeStructureAtoms;
    private extractJSStructureAtoms;
    private extractJavaStructureAtoms;
    private extractPythonStructureAtoms;
    private addAtomsToOpenCog;
}
//# sourceMappingURL=code-change-sensor.d.ts.map