import { ReactWidget } from '@theia/core/lib/browser/widgets/react-widget';
import { MessageService } from '@theia/core/lib/common/message-service';
import React from 'react';
import { ProductionOptimizationService } from '../common';
export declare const PRODUCTION_MONITORING_WIDGET_ID = "production.monitoring";
export declare class ProductionMonitoringWidget extends ReactWidget {
    static readonly ID = "production.monitoring";
    static readonly LABEL = "Production Monitoring";
    protected readonly productionService: ProductionOptimizationService;
    protected readonly messageService: MessageService;
    constructor();
    protected onActivateRequest(): void;
    protected render(): React.ReactNode;
}
//# sourceMappingURL=production-monitoring-widget.d.ts.map