import { Agent } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { EditorManager } from '@theia/editor/lib/browser';
import { MessageService } from '@theia/core';
import { OpenCogService, KnowledgeManagementService } from '../common';
export interface AssistanceContext {
    currentFile?: string;
    selectedText?: string;
    cursorPosition?: {
        line: number;
        column: number;
    };
    projectContext?: {
        language: string;
        framework?: string;
        dependencies: string[];
    };
    userIntent?: 'debugging' | 'refactoring' | 'feature-development' | 'learning' | 'optimization';
    problemDescription?: string;
}
export interface AssistanceResponse {
    suggestions: Array<{
        type: 'code-completion' | 'refactoring' | 'debugging' | 'explanation' | 'best-practice';
        title: string;
        description: string;
        confidence: number;
        codeExample?: string;
        reasoning: string;
        learnMoreLink?: string;
    }>;
    contextualInsights: string[];
    nextSteps: string[];
    learningOpportunities: string[];
    confidence: number;
}
/**
 * Intelligent Assistance Agent for Phase 3 AI Agent Enhancement
 *
 * Provides context-aware intelligent assistance including:
 * - Smart code suggestions based on cognitive analysis
 * - Real-time debugging assistance with reasoning
 * - Learning-oriented explanations for educational purposes
 * - Contextual best practice recommendations
 * - Adaptive assistance based on user expertise level
 */
export declare class IntelligentAssistanceAgent extends Agent {
    private readonly openCogService;
    private readonly knowledgeService;
    private readonly workspaceService;
    private readonly editorManager;
    private readonly messageService;
    private assistanceHistory;
    private userExpertiseProfile;
    private contextualKnowledgeCache;
    constructor(openCogService: OpenCogService, knowledgeService: KnowledgeManagementService, workspaceService: WorkspaceService, editorManager: EditorManager, messageService: MessageService);
    private initializeAssistanceCapabilities;
    private initializeUserProfiling;
    private setupContextualTriggers;
    private initializeAssistanceKnowledge;
    private seedAssistanceKnowledge;
    /**
     * Provide intelligent assistance based on current context
     */
    provideIntelligentAssistance(context: AssistanceContext): Promise<AssistanceResponse>;
    private analyzeAssistanceContext;
    private generateCognitiveSuggestions;
    private generateCodeCompletionSuggestion;
    private generateDebuggingSuggestions;
    private generateRefactoringSuggestions;
    private generateBestPracticeSuggestions;
    private generateExplanationSuggestions;
    private generateContextualInsights;
    private generateNextSteps;
    private generateLearningOpportunities;
    private calculateAssistanceConfidence;
    private learnFromAssistanceInteraction;
    private generateFallbackResponse;
    private analyzeAssistanceOpportunities;
    private extractLanguageExpertise;
    private extractFrameworkExpertise;
    private extractPatternExpertise;
    private extractProblemSolvingStyle;
    private extractLearningPreferences;
    private calculateComplexityFromPatterns;
    private calculateErrorLikelihood;
    private calculateRefactoringNeed;
    private generateCodeExample;
    /**
     * Provide debugging assistance with step-by-step guidance
     */
    provideDebuggingAssistance(context: {
        errorMessage?: string;
        stackTrace?: string;
        codeContext: string;
        expectedBehavior?: string;
        actualBehavior?: string;
    }): Promise<{
        debuggingSteps: Array<{
            step: number;
            title: string;
            description: string;
            reasoning: string;
            codeToCheck?: string;
        }>;
        possibleCauses: string[];
        quickFixes: string[];
        confidence: number;
    }>;
}
//# sourceMappingURL=intelligent-assistance-agent.d.ts.map