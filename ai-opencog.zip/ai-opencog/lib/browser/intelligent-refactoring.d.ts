import { ITextModel } from '@theia/monaco-editor-core/esm/vs/editor/common/model';
import { Range } from '@theia/monaco-editor-core/esm/vs/editor/common/core/range';
import { OpenCogService } from '../common/opencog-service';
import { PatternRecognitionAgent } from './pattern-recognition-agent';
export interface RefactoringSuggestion {
    id: string;
    title: string;
    description: string;
    range: Range;
    confidence: number;
    category: 'code-quality' | 'performance' | 'maintainability' | 'design-pattern';
    changes: Array<{
        range: Range;
        newText: string;
        description: string;
    }>;
}
export interface CodeQualityIssue {
    id: string;
    severity: 'error' | 'warning' | 'info';
    message: string;
    range: Range;
    suggestions: RefactoringSuggestion[];
}
/**
 * Intelligent Refactoring Provider using OpenCog reasoning
 * for code quality analysis, refactoring opportunity detection,
 * and automated refactoring execution
 */
export declare class IntelligentRefactoringProvider {
    private readonly opencog;
    private readonly patternAgent;
    constructor(opencog: OpenCogService, patternAgent: PatternRecognitionAgent);
    /**
     * Analyze code quality and detect issues
     */
    analyzeCodeQuality(model: ITextModel): Promise<CodeQualityIssue[]>;
    /**
     * Detect refactoring opportunities
     */
    detectRefactoringOpportunities(model: ITextModel): Promise<RefactoringSuggestion[]>;
    /**
     * Execute automated refactoring
     */
    executeRefactoring(suggestion: RefactoringSuggestion, model: ITextModel): Promise<boolean>;
    private createQualityIssue;
    private analyzeComplexity;
    private detectDuplication;
    private detectExtractMethodOpportunities;
    private detectExtractVariableOpportunities;
    private detectInlineOpportunities;
    private detectDesignPatternOpportunities;
    private generateRefactoringSuggestionsForPattern;
    private patternToRange;
    private getSeverityForPattern;
    private getIndentLevel;
    private detectLanguage;
}
//# sourceMappingURL=intelligent-refactoring.d.ts.map