import { Agent } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { EditorManager } from '@theia/editor/lib/browser';
import { OpenCogService, KnowledgeManagementService } from '../common';
/**
 * Comprehensive Cognitive Code Analysis Agent for Phase 3 AI Agent Enhancement
 *
 * This agent provides advanced cognitive analysis capabilities including:
 * - Deep semantic code understanding using OpenCog reasoning
 * - Real-time cognitive feedback during coding
 * - Learning from developer behavior and preferences
 * - Intelligent assistance based on cognitive patterns
 * - Collaborative team insights and knowledge sharing
 */
export declare class ComprehensiveCodeAnalysisAgent extends Agent {
    private readonly openCogService;
    private readonly knowledgeService;
    private readonly workspaceService;
    private readonly editorManager;
    private collaborativeKnowledgeGraph;
    private userBehaviorPatterns;
    private cognitiveAnalysisCache;
    constructor(openCogService: OpenCogService, knowledgeService: KnowledgeManagementService, workspaceService: WorkspaceService, editorManager: EditorManager);
    private initializeCognitiveInfrastructure;
    private setupCollaborativeKnowledgeGraph;
    private seedCollaborativeKnowledge;
    private setupRealtimeEditorIntegration;
    private setupEditorCognitiveFeatures;
    private scheduleRealtimeAnalysis;
    private performRealtimeAnalysis;
    private performQuickCognitiveAnalysis;
    private updateEditorCognitiveDecorations;
    private trackCursorBehavior;
    private learnFromCodingSession;
    private calculateQuickQualityScore;
    private hashContent;
    private initializeUserBehaviorLearning;
    /**
     * Comprehensive cognitive analysis of code with deep reasoning
     */
    performComprehensiveCognitiveAnalysis(fileUri: string, options?: {
        includeCollaborativeInsights?: boolean;
        adaptToUserBehavior?: boolean;
        generateRecommendations?: boolean;
    }): Promise<any>;
    private performSemanticAnalysis;
    private performArchitecturalAnalysis;
    private performSecurityAnalysis;
    private performPerformanceAnalysis;
    private performCollaborativeAnalysis;
    private performBehavioralAdaptation;
    private synthesizeCognitiveResults;
    private generateComprehensiveRecommendations;
    private calculateSemanticScore;
    private calculateAbstractionLevel;
    private calculateNamingConsistency;
    private calculateArchitectureScore;
    private calculateDependencyHealth;
    private calculateLayerSeparation;
    private calculateSecurityScore;
    private calculateRiskLevel;
    private calculatePerformanceScore;
    private calculateCollaborativeScore;
    private calculateTeamAlignment;
    private calculateBehaviorMatch;
    private calculateOverallScore;
    private calculateComplexityScore;
    private calculateMaintainabilityScore;
    private extractKeyFindings;
    private getUserAnalysisPreferences;
    private generatePersonalizedInsights;
    private readFileContent;
}
//# sourceMappingURL=comprehensive-code-analysis-agent.d.ts.map