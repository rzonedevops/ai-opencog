import { ToolInvocationContribution, ToolRequest } from '@theia/ai-core';
import { OpenCogService } from '../common/opencog-service';
import { AtomSpaceService } from '../node/atomspace-service';
import { KnowledgeManagementService } from '../common/knowledge-management-service';
/**
 * Tool contribution that registers OpenCog-specific tools with Theia's AI framework.
 * Demonstrates the tool registry integration pattern identified in the analysis.
 */
export declare class OpenCogToolContribution implements ToolInvocationContribution {
    protected readonly openCogService: OpenCogService;
    protected readonly atomSpaceService: AtomSpaceService;
    protected readonly knowledgeService: KnowledgeManagementService;
    getTools(): ToolRequest[];
    private createAtomSpaceQueryTool;
    private createCognitiveReasoningTool;
    private createPatternRecognitionTool;
    private createBehaviorLearningTool;
    private createAdaptationStrategyTool;
    private createKnowledgeExtractionTool;
    private createCognitiveAnalysisTool;
    private createLearningModelTool;
    private generatePatternDescription;
    private calculateOverallConfidence;
}
//# sourceMappingURL=opencog-tool-contribution.d.ts.map