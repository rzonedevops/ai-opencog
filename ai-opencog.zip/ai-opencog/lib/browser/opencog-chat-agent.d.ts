import { AbstractStreamParsingChatAgent, SystemMessageDescription } from '@theia/ai-chat/lib/common/chat-agents';
import { LanguageModelRequirement, AIVariableContext } from '@theia/ai-core';
import { MutableChatRequestModel } from '@theia/ai-chat/lib/common/chat-model';
import { OpenCogService } from '../common/opencog-service';
import { IntelligentAssistanceAgent } from './intelligent-assistance-agent';
import { AdvancedReasoningAgent } from './advanced-reasoning-agent';
import { UserBehaviorLearningAgent } from './user-behavior-learning-agent';
import { KnowledgeManagementService } from '../common/knowledge-management-service';
/**
 * OpenCog Chat Agent that integrates cognitive reasoning capabilities
 * with the main Theia AI chat system.
 */
export declare class OpenCogChatAgent extends AbstractStreamParsingChatAgent {
    private readonly openCogService;
    private readonly assistanceAgent;
    private readonly reasoningAgent;
    private readonly learningAgent;
    private readonly knowledgeService;
    readonly id = "opencog";
    readonly name = "OpenCog Reasoning";
    readonly description = "AI assistant powered by OpenCog cognitive reasoning with adaptive learning and knowledge management";
    readonly languageModelRequirements: LanguageModelRequirement[];
    protected readonly defaultLanguageModelPurpose = "chat";
    iconClass: string;
    locations: any[];
    tags: string[];
    constructor(openCogService: OpenCogService, assistanceAgent: IntelligentAssistanceAgent, reasoningAgent: AdvancedReasoningAgent, learningAgent: UserBehaviorLearningAgent, knowledgeService: KnowledgeManagementService);
    protected getSystemMessageDescription(context: AIVariableContext): Promise<SystemMessageDescription | undefined>;
    invoke(request: MutableChatRequestModel): Promise<void>;
    private performCognitiveAnalysis;
    private addCognitiveTransparency;
    private addErrorResponse;
    private isDebuggingQuery;
    private isCodeAnalysisQuery;
    private assessComplexity;
    private inferUserIntent;
    private getCurrentFile;
}
//# sourceMappingURL=opencog-chat-agent.d.ts.map