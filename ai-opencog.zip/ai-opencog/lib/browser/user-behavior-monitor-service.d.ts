import { Event, Disposable } from '@theia/core';
import { EditorManager } from '@theia/editor/lib/browser';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { FileService } from '@theia/filesystem/lib/browser';
import { CommandRegistry } from '@theia/core/lib/common/command';
import { KeybindingRegistry } from '@theia/core/lib/browser/keybinding';
import { UserBehaviorLearningAgent } from './user-behavior-learning-agent';
import { LearningAgent } from './enhanced-learning-agent';
export interface UserInteractionEvent {
    type: 'editor' | 'command' | 'file' | 'keyboard' | 'workspace';
    action: string;
    timestamp: number;
    context: Record<string, any>;
    userId: string;
    sessionId: string;
    duration?: number;
    success?: boolean;
}
export declare const UserBehaviorMonitorService: unique symbol;
/**
 * Service that monitors user interactions across the IDE and feeds data to learning agents
 * Part of Phase 3: AI Agent Enhancement for comprehensive user behavior learning
 */
export declare class UserBehaviorMonitorService implements Disposable {
    private readonly editorManager;
    private readonly workspaceService;
    private readonly fileService;
    private readonly commandRegistry;
    private readonly keybindingRegistry;
    private readonly behaviorAgent;
    private readonly learningAgent;
    private readonly onBehaviorDetectedEmitter;
    readonly onBehaviorDetected: Event<UserInteractionEvent>;
    private readonly disposables;
    private sessionId;
    private userId;
    private commandStartTimes;
    private lastEditorActivity;
    constructor(editorManager: EditorManager, workspaceService: WorkspaceService, fileService: FileService, commandRegistry: CommandRegistry, keybindingRegistry: KeybindingRegistry, behaviorAgent: UserBehaviorLearningAgent, learningAgent: LearningAgent);
    protected init(): void;
    dispose(): void;
    /**
     * Set the current user ID (would typically come from authentication service)
     */
    setUserId(userId: string): void;
    /**
     * Start a new monitoring session
     */
    startNewSession(): void;
    /**
     * Get current session statistics
     */
    getSessionStats(): {
        sessionId: string;
        userId: string;
        startTime: number;
        totalInteractions: number;
    };
    private setupEditorMonitoring;
    private setupCommandMonitoring;
    private setupFileSystemMonitoring;
    private setupWorkspaceMonitoring;
    private setupBehaviorLearningIntegration;
    private emitBehaviorEvent;
    private countLinesChanged;
    private handleCodeQualityEvent;
    private isWorkflowRelevantEvent;
    private handleWorkflowEvent;
    private getCommandFrequency;
    private getRecentFileAccess;
    private generateSessionId;
}
//# sourceMappingURL=user-behavior-monitor-service.d.ts.map