import { Agent, LanguageModelRequirement, PromptVariantSet } from '@theia/ai-core';
import { OpenCogService } from './opencog-service';
/**
 * Example implementation of a cognitive analysis agent that demonstrates
 * the integration patterns identified in the Theia AI Framework Analysis.
 *
 * This agent showcases:
 * - Integration with OpenCog services
 * - Use of cognitive variables and context
 * - Tool function integration
 * - Sophisticated prompt templates
 * - Learning and adaptation capabilities
 */
export declare class CognitiveAnalysisAgent implements Agent {
    protected readonly openCogService: OpenCogService;
    readonly id = "cognitive-analysis";
    readonly name = "Cognitive Analysis";
    readonly description = "\n        Advanced cognitive analysis agent powered by OpenCog integration.\n        \n        **Capabilities:**\n        - Cognitive reasoning using OpenCog's PLN (Probabilistic Logic Networks)\n        - Pattern recognition in code and data structures\n        - Learning from user feedback and behavior\n        - Context-aware analysis and adaptation\n        - Knowledge extraction from AtomSpace\n        \n        **Privacy Notice:**\n        This agent accesses code content, user behavior patterns, and learning data\n        to provide personalized cognitive analysis. All data is processed locally\n        within the OpenCog AtomSpace system.\n    ";
    readonly variables: string[];
    readonly functions: string[];
    readonly languageModelRequirements: LanguageModelRequirement[];
    readonly tags: string[];
    readonly agentSpecificVariables: {
        name: string;
        description: string;
        usedInPrompt: boolean;
    }[];
    readonly prompts: PromptVariantSet[];
    /**
     * Example method showing how the agent would integrate with OpenCog services
     * This is not part of the Agent interface but demonstrates the integration pattern
     */
    performCognitiveAnalysis(input: {
        text: string;
        context?: any;
        userPreferences?: any;
    }): Promise<{
        analysis: any;
        patterns: any[];
        reasoning: any;
        confidence: number;
    }>;
    /**
     * Example method for learning from user feedback
     */
    learnFromInteraction(interaction: {
        request: string;
        response: string;
        feedback: {
            rating: number;
            helpful: boolean;
            comment?: string;
        };
        context: any;
    }): Promise<void>;
    /**
     * Example method for adaptive behavior
     */
    adaptToUser(userId: string, domain: string): Promise<any>;
}
//# sourceMappingURL=cognitive-analysis-agent-example.d.ts.map