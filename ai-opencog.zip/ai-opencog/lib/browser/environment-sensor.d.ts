import { Disposable } from '@theia/core/lib/common/disposable';
import { TaskService } from '@theia/task/lib/browser/task-service';
import { ProblemManager } from '@theia/markers/lib/browser/problem/problem-manager';
import { MarkerManager } from '@theia/markers/lib/browser/marker-manager';
import { OpenCogService } from '../common/opencog-service';
import { EnvironmentMetrics, Sensor } from '../common/sensor-motor-types';
/**
 * Monitors development environment including build processes, performance metrics, and resource utilization
 */
export declare class EnvironmentSensor implements Sensor, Disposable {
    private readonly taskService;
    private readonly problemManager;
    private readonly markerManager;
    private readonly opencog;
    protected disposables: any;
    protected active: boolean;
    protected metricsHistory: EnvironmentMetrics[];
    private readonly maxHistorySize;
    private metricsInterval?;
    constructor(taskService: TaskService, problemManager: ProblemManager, markerManager: MarkerManager, opencog: OpenCogService);
    start(): Promise<void>;
    stop(): Promise<void>;
    isActive(): boolean;
    dispose(): void;
    private setupBuildMonitoring;
    private setupProblemMonitoring;
    private startPeriodicMetricsCollection;
    private collectSystemMetrics;
    private getMemoryUsage;
    private getPerformanceMetrics;
    private recordBuildMetrics;
    private recordProblemMetrics;
    private recordMetrics;
    private extractEnvironmentAtoms;
    private calculateBuildPerformanceStrength;
    private calculatePerformanceStrength;
    private addAtomsToOpenCog;
    /**
     * Get recent metrics history
     */
    getMetricsHistory(limit?: number): EnvironmentMetrics[];
    /**
     * Get environment statistics
     */
    getEnvironmentStats(): Record<string, any>;
}
//# sourceMappingURL=environment-sensor.d.ts.map