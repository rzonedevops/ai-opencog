import { Agent } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { OpenCogService, UserFeedback } from '../common';
/**
 * Specialized agent for learning and adaptation within the IDE
 */
export declare class LearningAdaptationAgent implements Agent {
    private readonly openCogService;
    private readonly workspaceService;
    readonly id = "opencog-learning-adaptation";
    readonly name = "Learning & Adaptation Agent";
    readonly description = "OpenCog-powered agent that learns from user behavior and adapts the IDE experience";
    constructor(openCogService: OpenCogService, workspaceService: WorkspaceService);
    /**
     * Learn from user feedback on suggestions or actions
     */
    learnFromFeedback(userId: string, suggestion: any, feedback: UserFeedback, context?: any): Promise<void>;
    /**
     * Learn from user behavior patterns
     */
    learnUserBehavior(userId: string, action: string, context: any): Promise<void>;
    /**
     * Adapt IDE behavior based on user patterns
     */
    adaptToUser(userId: string, domain: string, currentData: any): Promise<any>;
    /**
     * Predict user's next likely action
     */
    predictUserAction(userId: string, context: any): Promise<{
        action: string;
        confidence: number;
    }[]>;
    /**
     * Get personalized recommendations for the user
     */
    getPersonalizedRecommendations(userId: string, context: any): Promise<any[]>;
    /**
     * Learn from code editing patterns
     */
    learnCodeEditingPatterns(userId: string, editAction: {
        type: 'insert' | 'delete' | 'replace';
        content: string;
        location: {
            line: number;
            column: number;
        };
        fileType: string;
    }, context: any): Promise<void>;
    /**
     * Learn from debugging sessions
     */
    learnDebuggingPatterns(userId: string, debugSession: {
        issueType: string;
        resolution: string;
        timeSpent: number;
        successful: boolean;
    }, context: any): Promise<void>;
    /**
     * Continuous learning from IDE usage
     */
    startContinuousLearning(userId: string): Promise<void>;
    private determineLearningPriority;
    private applyAdaptationStrategy;
    private generateRecommendations;
}
//# sourceMappingURL=learning-adaptation-agent.d.ts.map