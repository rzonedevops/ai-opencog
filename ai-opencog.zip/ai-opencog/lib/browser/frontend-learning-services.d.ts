import { WebSocketConnectionProvider } from '@theia/core/lib/browser/messaging';
import { SupervisedLearningService, LearningResult, UnsupervisedLearningService, PatternDiscoveryResult, WorkflowOptimizationResult, ReinforcementLearningService, OutcomeBasedInput, SuccessPattern } from '../common/learning-services';
import { UserFeedback, LearningContext } from '../common/opencog-types';
/**
 * Frontend proxy for SupervisedLearningService
 */
export declare class FrontendSupervisedLearningService implements SupervisedLearningService {
    private readonly service;
    constructor(connectionProvider: WebSocketConnectionProvider);
    learnFromFeedback(action: string, feedback: UserFeedback): Promise<LearningResult>;
    trainWithExamples(examples: {
        input: any;
        output: any;
    }[]): Promise<LearningResult>;
    predictOutcome(input: any, context?: LearningContext): Promise<{
        prediction: any;
        confidence: number;
    }>;
}
/**
 * Frontend proxy for UnsupervisedLearningService
 */
export declare class FrontendUnsupervisedLearningService implements UnsupervisedLearningService {
    private readonly service;
    constructor(connectionProvider: WebSocketConnectionProvider);
    discoverCodePatterns(codeData: any[]): Promise<PatternDiscoveryResult>;
    learnWorkflowOptimizations(workflowData: any[]): Promise<WorkflowOptimizationResult>;
    learnQualityMetrics(qualityData: any[]): Promise<{
        metrics: any[];
        confidence: number;
    }>;
}
/**
 * Frontend proxy for ReinforcementLearningService
 */
export declare class FrontendReinforcementLearningService implements ReinforcementLearningService {
    private readonly service;
    constructor(connectionProvider: WebSocketConnectionProvider);
    learnFromOutcome(input: OutcomeBasedInput): Promise<LearningResult>;
    recognizeSuccessPatterns(data: any[]): Promise<SuccessPattern[]>;
    optimizeAdaptiveAssistance(userId: string, context: LearningContext): Promise<{
        optimizations: any[];
        confidence: number;
    }>;
}
//# sourceMappingURL=frontend-learning-services.d.ts.map