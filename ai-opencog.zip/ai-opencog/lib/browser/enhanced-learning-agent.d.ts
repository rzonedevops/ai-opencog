import { Agent, LanguageModelRequirement } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { OpenCogService } from '../common/opencog-service';
import { AdaptationStrategy } from '../common/opencog-types';
export interface DeveloperBehaviorLearning {
    userId: string;
    patterns: {
        codingStyle: {
            preferredIndentation: number;
            bracketStyle: 'same-line' | 'new-line';
            namingConvention: 'camelCase' | 'snake_case' | 'kebab-case';
            commentingFrequency: number;
        };
        workflowPreferences: {
            preferredFileOrder: string[];
            commonCommands: string[];
            breakFrequency: number;
            sessionDuration: number;
        };
        errorPatterns: {
            commonMistakes: string[];
            bugTypes: string[];
            debuggingApproach: string;
        };
    };
    confidenceScore: number;
    lastUpdated: number;
}
export interface CodeQualityLearning {
    qualityMetrics: {
        averageComplexity: number;
        maintainabilityTrend: number[];
        performanceImprovements: number;
        refactoringSuccess: number;
    };
    patterns: {
        successfulRefactorings: string[];
        effectivePatterns: string[];
        avoidedAntiPatterns: string[];
    };
    recommendations: {
        personalizedSuggestions: string[];
        adaptiveGuidance: string[];
    };
}
export interface WorkflowOptimization {
    optimizationId: string;
    category: 'shortcuts' | 'automation' | 'templates' | 'navigation';
    description: string;
    potentialTimeSaving: number;
    confidence: number;
    implementation: string;
}
/**
 * Learning Agent for developer behavior learning, code quality pattern learning,
 * and workflow optimization learning as specified in Phase 2 requirements
 */
export declare class LearningAgent implements Agent {
    private readonly opencog;
    private readonly workspace;
    readonly id = "opencog-learning";
    readonly name = "Learning Agent";
    readonly description = "Learns from developer behavior, code quality, and workflows";
    readonly variables: string[];
    readonly functions: string[];
    readonly prompts: {
        id: string;
        content: string;
    }[];
    languageModelRequirements: LanguageModelRequirement[];
    private developerProfiles;
    private codeQualityData;
    private workflowOptimizations;
    constructor(opencog: OpenCogService, workspace: WorkspaceService);
    /**
     * Learn from developer behavior patterns
     */
    learnDeveloperBehavior(userId: string, action: string, context: any): Promise<void>;
    /**
     * Learn from code quality patterns and improvements
     */
    learnCodeQualityPatterns(userId: string, qualityData: any): Promise<void>;
    /**
     * Learn and optimize workflow patterns
     */
    learnWorkflowOptimization(userId: string, workflowData: any): Promise<WorkflowOptimization[]>;
    /**
     * Get personalized recommendations based on learning
     */
    getPersonalizedRecommendations(userId: string): Promise<string[]>;
    /**
     * Get adaptation strategy for a specific user and domain
     */
    getAdaptationStrategy(userId: string, domain: string): Promise<AdaptationStrategy | undefined>;
    /**
     * Provide feedback on learning effectiveness
     */
    provideLearningFeedback(userId: string, feedbackType: string, isPositive: boolean, context?: any): Promise<void>;
    /**
     * Get learning statistics and insights
     */
    getLearningInsights(userId: string): Promise<any>;
    private initializeLearningModels;
    private getDeveloperProfile;
    private createDefaultProfile;
    private createDefaultQualityLearning;
    private updateBehaviorProfile;
    private updateQualityMetrics;
    private generatePersonalizedRecommendations;
    private analyzeWorkflowEfficiency;
    private findCommonFileTransitions;
    private calculateLearningProgress;
    private calculateTotalTimeSavings;
}
//# sourceMappingURL=enhanced-learning-agent.d.ts.map