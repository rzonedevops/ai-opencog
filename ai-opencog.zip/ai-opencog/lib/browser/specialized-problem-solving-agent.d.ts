import { Agent } from '@theia/ai-core/lib/common/agent';
import { OpenCogService, KnowledgeManagementService } from '../common';
import { ProblemContext, ReasoningSolution } from './advanced-reasoning-agent';
/**
 * Specialized Problem-Solving Strategies
 */
export interface ProblemSolvingStrategy {
    name: string;
    description: string;
    applicableDomains: string[];
    complexity: ('low' | 'medium' | 'high' | 'expert')[];
    execute(problem: ProblemContext): Promise<ReasoningSolution>;
}
/**
 * Problem-Solving Context with Enhanced Metadata
 */
export interface EnhancedProblemContext extends ProblemContext {
    stakeholders?: string[];
    businessImpact?: 'low' | 'medium' | 'high' | 'critical';
    technicalDebt?: number;
    riskTolerance?: 'low' | 'medium' | 'high';
    iterationPreference?: 'waterfall' | 'agile' | 'lean';
    knowledgeGaps?: string[];
}
/**
 * Solution Quality Metrics
 */
export interface SolutionMetrics {
    technicalQuality: number;
    implementationComplexity: number;
    riskLevel: number;
    timeToValue: number;
    maintainability: number;
    scalability: number;
    overallScore: number;
}
/**
 * Enhanced Reasoning Agent for Specialized Problem-Solving
 *
 * This agent extends the Advanced Reasoning Agent with specialized strategies for:
 * - Domain-specific problem-solving approaches
 * - Multi-stakeholder problem analysis
 * - Risk-aware solution generation
 * - Iterative solution refinement
 * - Quality-driven solution evaluation
 */
export declare class SpecializedProblemSolvingAgent extends Agent {
    private readonly openCogService;
    private readonly knowledgeService;
    private problemSolvingStrategies;
    private solutionHistory;
    private domainExpertise;
    constructor(openCogService: OpenCogService, knowledgeService: KnowledgeManagementService);
    private initializeSpecializedStrategies;
    private registerDebuggingStrategies;
    private registerArchitectureStrategies;
    private registerPerformanceStrategies;
    private registerSecurityStrategies;
    private registerIntegrationStrategies;
    /**
     * Solve problems using specialized strategies
     */
    solveWithSpecializedStrategy(problem: EnhancedProblemContext): Promise<ReasoningSolution>;
    private analyzeSpecializedProblem;
    private selectSpecializedStrategy;
    private scoreStrategyForProblem;
    private executeSystematicDebugging;
    private executeHypothesisDebugging;
    private executeDomainDrivenDesign;
    private executeEvolutionaryArchitecture;
    private executePerformanceProfiling;
    private executeLoadTestingOptimization;
    private executeThreatModeling;
    private executeSecurityByDesign;
    private executeApiFirstIntegration;
    private executeEventDrivenIntegration;
    private generateSpecializedSolution;
    private evaluateSolutionQuality;
    private enhanceSolutionWithSpecializedInsights;
    private learnFromSpecializedSolution;
    private generateSpecializedFallbackSolution;
    private calculateComplexityScore;
    private mapBusinessImpactToScore;
    private mapRiskToleranceToScore;
    private getHistoricalStrategySuccess;
    private calculateTechnicalQuality;
    private calculateImplementationComplexity;
    private calculateRiskLevel;
    private calculateTimeToValue;
    private calculateMaintainability;
    private calculateScalability;
    private storeSolutionInHistory;
}
//# sourceMappingURL=specialized-problem-solving-agent.d.ts.map