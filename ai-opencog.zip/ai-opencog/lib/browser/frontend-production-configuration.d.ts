import { ProductionConfigurationService, ProductionConfig, EnvironmentSettings } from '../common/production-configuration';
import { PreferenceService } from '@theia/core/lib/browser';
/**
 * Frontend implementation of ProductionConfigurationService
 */
export declare class FrontendProductionConfigurationService extends ProductionConfigurationService {
    protected readonly preferenceService: PreferenceService;
    constructor();
    /**
     * Get configuration with frontend-specific optimizations
     */
    getConfiguration(): Promise<ProductionConfig>;
    /**
     * Apply configuration changes with UI feedback
     */
    applyConfigurationWithFeedback(updates: Partial<ProductionConfig>): Promise<void>;
    /**
     * Get browser-specific environment settings
     */
    getBrowserEnvironmentSettings(): Promise<EnvironmentSettings & {
        browser: boolean;
        userAgent: string;
    }>;
}
//# sourceMappingURL=frontend-production-configuration.d.ts.map