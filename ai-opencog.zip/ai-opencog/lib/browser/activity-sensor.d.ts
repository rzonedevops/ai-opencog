import { Disposable } from '@theia/core/lib/common/disposable';
import { EditorManager } from '@theia/editor/lib/browser/editor-manager';
import { NavigatorContribution } from '@theia/navigator/lib/browser/navigator-contribution';
import { TerminalService } from '@theia/terminal/lib/browser/base/terminal-service';
import { TaskService } from '@theia/task/lib/browser/task-service';
import { DebugService } from '@theia/debug/lib/browser/debug-service';
import { OpenCogService } from '../common/opencog-service';
import { UserActivity, Sensor } from '../common/sensor-motor-types';
/**
 * Monitors user activity including editor interactions, tool usage, and workflow patterns
 */
export declare class ActivitySensor implements Sensor, Disposable {
    private readonly editorManager;
    private readonly navigator;
    private readonly terminalService;
    private readonly taskService;
    private readonly debugService;
    private readonly opencog;
    protected disposables: any;
    protected active: boolean;
    protected activityHistory: UserActivity[];
    private readonly maxHistorySize;
    constructor(editorManager: EditorManager, navigator: NavigatorContribution, terminalService: TerminalService, taskService: TaskService, debugService: DebugService, opencog: OpenCogService);
    start(): Promise<void>;
    stop(): Promise<void>;
    isActive(): boolean;
    dispose(): void;
    private setupEditorMonitoring;
    private setupNavigatorMonitoring;
    private setupTerminalMonitoring;
    private setupTaskMonitoring;
    private setupDebugMonitoring;
    private recordActivity;
    private extractActivityAtoms;
    private detectWorkflowPatterns;
    private findSequentialPatterns;
    private createWorkflowPatternAtoms;
    private addAtomsToOpenCog;
    /**
     * Get recent activity history
     */
    getActivityHistory(limit?: number): UserActivity[];
    /**
     * Get activity statistics
     */
    getActivityStats(): Record<string, any>;
}
//# sourceMappingURL=activity-sensor.d.ts.map