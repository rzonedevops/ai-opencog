import { Agent } from '@theia/ai-core/lib/common/agent';
import { WorkspaceService } from '@theia/workspace/lib/browser';
import { OpenCogService, KnowledgeManagementService } from '../common';
import { Atom } from '../common/opencog-types';
/**
 * OpenCog-powered code analysis agent that extends Theia's AI agent system
 * Enhanced with knowledge management capabilities
 */
export declare class CodeAnalysisAgent extends Agent {
    private readonly openCogService;
    private readonly knowledgeService;
    private readonly workspaceService;
    private codeKnowledgeGraph;
    constructor(openCogService: OpenCogService, knowledgeService: KnowledgeManagementService, workspaceService: WorkspaceService);
    private initializeCodeKnowledge;
    private seedCodeKnowledge;
    analyzeCode(fileUri: string): Promise<any>;
    private discoverRelatedKnowledge;
    private generateEnhancedRecommendations;
    private getCodeKnowledgeMetrics;
    searchCodeKnowledge(query: string): Promise<Atom[]>;
    getCategorizedCodeConcepts(): Promise<Map<string, Atom[]>>;
    private readFile;
    private extractCodeAtoms;
    private generatePatternBasedRecommendations;
    private calculateCodeQualityMetrics;
    private extractCodeAtomsFromPatterns;
    private createCodePatternAtoms;
    private createDesignPatternAtoms;
    private createAsyncPatternAtoms;
    private createReactivePatternAtoms;
    private detectLanguage;
}
//# sourceMappingURL=code-analysis-agent.d.ts.map