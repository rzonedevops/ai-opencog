import { Agent } from '@theia/ai-core';
import { OpenCogService } from '../common/opencog-service';
import { AdvancedLearningService } from '../common/advanced-learning-service';
import { AdvancedLearningData, AdvancedLearningResult, AdvancedLearningModel, NeuralNetworkConfig, MetaLearningConfig, TransferLearningConfig, EnsembleLearningConfig, OnlineLearningConfig, ActiveLearningConfig, Tensor3D, LearningContext } from '../common/opencog-types';
/**
 * Advanced Learning Agent - Specialized agent for sophisticated machine learning algorithms
 * Part of Phase 5: Advanced Features in the SKZ Integration workflow
 */
export declare class AdvancedLearningAgent implements Agent {
    private readonly openCogService;
    private readonly advancedLearningService;
    readonly id = "opencog-advanced-learning";
    readonly name = "Advanced Learning Agent";
    readonly description = "Specialized agent for advanced machine learning algorithms including deep learning, meta-learning, and ensemble methods";
    readonly variables: string[];
    readonly functions: string[];
    constructor(openCogService: OpenCogService, advancedLearningService: AdvancedLearningService);
    /**
     * Create and configure a neural network for deep learning
     */
    createNeuralNetwork(userId: string, config: NeuralNetworkConfig, context: LearningContext): Promise<AdvancedLearningModel>;
    /**
     * Train a deep learning model with advanced optimization
     */
    trainDeepModel(modelId: string, trainingData: AdvancedLearningData[], validationData?: AdvancedLearningData[]): Promise<AdvancedLearningResult>;
    /**
     * Perform meta-learning for few-shot adaptation
     */
    performMetaLearning(config: MetaLearningConfig, tasks: AdvancedLearningData[][], context: LearningContext): Promise<AdvancedLearningResult>;
    /**
     * Perform transfer learning from pre-trained models
     */
    performTransferLearning(config: TransferLearningConfig, targetData: AdvancedLearningData[], context: LearningContext): Promise<AdvancedLearningResult>;
    /**
     * Create and manage ensemble learning models
     */
    createEnsemble(config: EnsembleLearningConfig, trainingData: AdvancedLearningData[], context: LearningContext): Promise<AdvancedLearningResult>;
    /**
     * Implement online learning for continuous adaptation
     */
    performOnlineLearning(config: OnlineLearningConfig, dataStream: AdvancedLearningData[], context: LearningContext): Promise<AdvancedLearningResult>;
    /**
     * Implement active learning for intelligent data selection
     */
    performActiveLearning(config: ActiveLearningConfig, labeledData: AdvancedLearningData[], unlabeledPool: any[], context: LearningContext): Promise<{
        model: AdvancedLearningModel;
        selectedSamples: any[];
        expectedImprovement: number;
    }>;
    /**
     * Process 3 DoF tensor data
     */
    processTensor3D(tensor: Tensor3D, operation: string, parameters?: Record<string, any>): Promise<Tensor3D>;
    /**
     * Get comprehensive analytics for advanced learning models
     */
    getAdvancedLearningAnalytics(userId: string): Promise<{
        modelSummary: any;
        performanceMetrics: any;
        recommendations: string[];
    }>;
    private selectMostInformativeSamples;
    private estimateImprovementFromSamples;
    private performTensor3DOperation;
    private calculateOutputShape3D;
    private findBestPerformingType;
    private identifyImprovementOpportunities;
    private calculateResourceEfficiency;
    private generateAdvancedLearningRecommendations;
}
//# sourceMappingURL=advanced-learning-agent.d.ts.map