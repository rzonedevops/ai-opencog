export {};
//# sourceMappingURL=phase2-cognitive-services.spec.d.ts.map