export {};
//# sourceMappingURL=cognitive-integration.spec.d.ts.map