export {};
//# sourceMappingURL=multi-modal-processing.spec.d.ts.map