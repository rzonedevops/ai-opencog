import { ProductionConfigurationService } from './production-configuration';
export interface DeploymentInfo {
    id: string;
    version: string;
    environment: string;
    status: 'pending' | 'deploying' | 'deployed' | 'failed' | 'rollback';
    timestamp: Date;
    healthStatus: 'healthy' | 'unhealthy' | 'unknown';
    metrics?: {
        cpuUsage: number;
        memoryUsage: number;
        responseTime: number;
        errorRate: number;
    };
}
export interface DeploymentOptions {
    version: string;
    environment: 'development' | 'staging' | 'production';
    validateHealthChecks: boolean;
    enableRollback: boolean;
    timeout: number;
}
export interface RollbackOptions {
    deploymentId: string;
    targetVersion?: string;
    reason: string;
}
/**
 * Production deployment orchestration service
 */
export declare class ProductionDeploymentService {
    protected readonly configService: ProductionConfigurationService;
    private deployments;
    private currentDeployment;
    /**
     * Deploy the OpenCog integration to production
     */
    deploy(options: DeploymentOptions): Promise<DeploymentInfo>;
    /**
     * Rollback to a previous deployment
     */
    rollback(options: RollbackOptions): Promise<DeploymentInfo>;
    /**
     * Get current deployment status
     */
    getCurrentDeployment(): DeploymentInfo | undefined;
    /**
     * Get deployment history
     */
    getDeploymentHistory(environment?: string): DeploymentInfo[];
    /**
     * Check health of current deployment
     */
    checkHealth(): Promise<{
        status: 'healthy' | 'unhealthy' | 'degraded';
        checks: Array<{
            name: string;
            status: boolean;
            details?: string;
        }>;
        metrics?: any;
    }>;
    private validatePreDeploymentRequirements;
    private deployContainer;
    private deployNative;
    private performHealthChecks;
    private checkServiceAvailability;
    private checkCognitiveServices;
    private checkResourceUsage;
    private collectMetrics;
    private findPreviousSuccessfulDeployment;
    private generateDeploymentId;
}
//# sourceMappingURL=production-deployment.d.ts.map