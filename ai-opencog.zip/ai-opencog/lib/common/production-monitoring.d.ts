import { Event } from '@theia/core/lib/common';
import { ProductionConfigurationService } from './production-configuration';
export interface ProductionMetrics {
    timestamp: Date;
    system: {
        cpuUsage: number;
        memoryUsage: number;
        memoryTotal: number;
        diskUsage: number;
        diskTotal: number;
        uptime: number;
    };
    application: {
        responseTime: number;
        throughput: number;
        errorRate: number;
        activeConnections: number;
        cognitiveOperations: number;
    };
    cognitive: {
        reasoningOperations: number;
        learningEvents: number;
        knowledgeBaseSize: number;
        averageInferenceTime: number;
        cacheHitRate: number;
    };
}
export interface LogEntry {
    timestamp: Date;
    level: 'error' | 'warn' | 'info' | 'debug';
    category: string;
    message: string;
    data?: any;
    context?: {
        userId?: string;
        sessionId?: string;
        operation?: string;
    };
}
export interface UsageAnalytics {
    period: {
        start: Date;
        end: Date;
    };
    users: {
        total: number;
        active: number;
        new: number;
    };
    features: {
        [feature: string]: {
            usageCount: number;
            uniqueUsers: number;
            averageSessionTime: number;
        };
    };
    cognitive: {
        totalOperations: number;
        operationsByType: {
            [type: string]: number;
        };
        averageResponseTime: number;
        successRate: number;
    };
}
export interface Alert {
    id: string;
    type: 'performance' | 'error' | 'usage' | 'system';
    severity: 'low' | 'medium' | 'high' | 'critical';
    message: string;
    timestamp: Date;
    acknowledged: boolean;
    resolved: boolean;
    data?: any;
}
/**
 * Enhanced production monitoring and logging service
 */
export declare class ProductionMonitoringService {
    protected readonly configService: ProductionConfigurationService;
    private readonly onMetricsUpdatedEmitter;
    private readonly onAlertEmitter;
    private readonly onUsageUpdateEmitter;
    private metricsHistory;
    private logEntries;
    private alerts;
    private usageData;
    private monitoringActive;
    private metricsInterval;
    readonly onMetricsUpdated: Event<ProductionMetrics>;
    readonly onAlert: Event<Alert>;
    readonly onUsageUpdate: Event<UsageAnalytics>;
    /**
     * Start production monitoring
     */
    startMonitoring(): Promise<void>;
    /**
     * Stop production monitoring
     */
    stopMonitoring(): Promise<void>;
    /**
     * Collect current metrics
     */
    collectMetrics(): Promise<ProductionMetrics>;
    /**
     * Log an entry
     */
    log(level: 'error' | 'warn' | 'info' | 'debug', category: string, message: string, data?: any, context?: any): void;
    /**
     * Track usage analytics
     */
    trackUsage(userId: string, feature: string, sessionTime: number, operation?: string): void;
    /**
     * Generate usage analytics report
     */
    generateUsageAnalytics(startDate: Date, endDate: Date): Promise<UsageAnalytics>;
    /**
     * Get recent metrics
     */
    getRecentMetrics(count?: number): ProductionMetrics[];
    /**
     * Get log entries
     */
    getLogEntries(level?: string, category?: string, limit?: number): LogEntry[];
    /**
     * Get active alerts
     */
    getActiveAlerts(): Alert[];
    /**
     * Acknowledge an alert
     */
    acknowledgeAlert(alertId: string): void;
    /**
     * Resolve an alert
     */
    resolveAlert(alertId: string): void;
    private collectSystemMetrics;
    private collectApplicationMetrics;
    private collectCognitiveMetrics;
    private checkAlerts;
    private createAlert;
}
//# sourceMappingURL=production-monitoring.d.ts.map