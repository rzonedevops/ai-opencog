export {};
//# sourceMappingURL=atomspace-service.spec.d.ts.map