export {};
//# sourceMappingURL=knowledge-management-service.spec.d.ts.map