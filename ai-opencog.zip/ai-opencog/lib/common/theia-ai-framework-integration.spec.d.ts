export {};
//# sourceMappingURL=theia-ai-framework-integration.spec.d.ts.map