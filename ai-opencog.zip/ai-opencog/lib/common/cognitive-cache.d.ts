/**
 * Copyright (c) 2024 Cognitive Intelligence Ventures.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
export interface CacheEntry {
    data: any;
    timestamp: number;
    expiry: number;
    accessCount: number;
    lastAccessed: number;
}
/**
 * Cognitive cache implementation for storing reasoning results, learning patterns, and other cognitive data
 */
export declare class CognitiveCache {
    private cache;
    private readonly defaultTtl;
    private readonly maxSize;
    private readonly cleanupInterval;
    private cleanupTimer?;
    constructor();
    /**
     * Get cached result by key
     */
    getCachedResult(key: string): Promise<any>;
    /**
     * Store result in cache with optional TTL
     */
    setCachedResult(key: string, data: any, ttl?: number): Promise<void>;
    /**
     * Check if cache entry has expired
     */
    private isExpired;
    /**
     * Remove least recently used entry
     */
    private evictLeastRecentlyUsed;
    /**
     * Start periodic cleanup of expired entries
     */
    private startCleanupTimer;
    /**
     * Clean up expired entries
     */
    private cleanupExpiredEntries;
    /**
     * Clear all cached entries
     */
    clear(): void;
    /**
     * Get cache statistics
     */
    getStats(): {
        size: number;
        maxSize: number;
        hitRate: number;
        entries: Array<{
            key: string;
            accessCount: number;
            age: number;
        }>;
    };
    /**
     * Check if key exists in cache and is not expired
     */
    has(key: string): boolean;
    /**
     * Remove specific cache entry
     */
    delete(key: string): boolean;
    /**
     * Dispose cleanup timer
     */
    dispose(): void;
}
//# sourceMappingURL=cognitive-cache.d.ts.map