import { PatternInput, PatternResult } from './opencog-types';
/**
 * Demonstration of enhanced pattern recognition capabilities
 */
export declare class PatternRecognitionDemo {
    /**
     * Demonstrate code pattern recognition
     */
    static getCodePatternExample(): PatternInput;
    /**
     * Demonstrate structural pattern recognition
     */
    static getStructuralPatternExample(): PatternInput;
    /**
     * Demonstrate behavioral pattern recognition
     */
    static getBehavioralPatternExample(): PatternInput;
    /**
     * Get expected pattern results for demonstration
     */
    static getExpectedPatternResults(): {
        code: Partial<PatternResult>[];
        structural: Partial<PatternResult>[];
        behavioral: Partial<PatternResult>[];
    };
    /**
     * Format pattern results for display
     */
    static formatPatternResults(patterns: PatternResult[]): string;
}
//# sourceMappingURL=pattern-recognition-demo.d.ts.map