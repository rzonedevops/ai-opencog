import { FeedbackIntegration } from './feedback-integration';
import { ProductionMonitoringService } from './production-monitoring';
export interface EnhancementRequest {
    id: string;
    title: string;
    description: string;
    category: 'feature' | 'performance' | 'cognitive' | 'usability' | 'documentation';
    priority: 'low' | 'medium' | 'high' | 'critical';
    status: 'submitted' | 'reviewing' | 'approved' | 'in-progress' | 'testing' | 'deployed' | 'rejected';
    submittedBy: string;
    submittedAt: Date;
    votes: number;
    feedback: string[];
    estimatedEffort: 'small' | 'medium' | 'large' | 'extra-large';
    targetVersion?: string;
}
export interface CommunityContribution {
    id: string;
    type: 'documentation' | 'tutorial' | 'example' | 'plugin' | 'improvement';
    title: string;
    description: string;
    contributor: string;
    submittedAt: Date;
    status: 'pending' | 'reviewed' | 'accepted' | 'merged' | 'rejected';
    reviewComments: string[];
    downloadCount?: number;
    rating?: number;
}
export interface ReleaseInfo {
    version: string;
    releaseDate: Date;
    features: string[];
    improvements: string[];
    bugFixes: string[];
    cognitiveEnhancements: string[];
    breakingChanges: string[];
    migrationGuide?: string;
}
/**
 * Community building and continuous enhancement service
 */
export declare class CommunityEnhancementService {
    protected readonly feedbackService: FeedbackIntegration;
    protected readonly monitoringService: ProductionMonitoringService;
    private enhancements;
    private contributions;
    private releases;
    /**
     * Submit an enhancement request
     */
    submitEnhancement(request: Omit<EnhancementRequest, 'id' | 'submittedAt' | 'votes' | 'feedback' | 'status'>): Promise<string>;
    /**
     * Vote for an enhancement
     */
    voteForEnhancement(enhancementId: string, userId: string): Promise<void>;
    /**
     * Submit a community contribution
     */
    submitContribution(contribution: Omit<CommunityContribution, 'id' | 'submittedAt' | 'status' | 'reviewComments'>): Promise<string>;
    /**
     * Review and accept/reject contribution
     */
    reviewContribution(contributionId: string, decision: 'accept' | 'reject', comments: string[]): Promise<void>;
    /**
     * Plan next release based on feedback and enhancements
     */
    planNextRelease(targetVersion: string): Promise<ReleaseInfo>;
    /**
     * Get community statistics
     */
    getCommunityStats(): {
        enhancements: {
            total: number;
            byStatus: {
                [status: string]: number;
            };
            byCategory: {
                [category: string]: number;
            };
        };
        contributions: {
            total: number;
            byType: {
                [type: string]: number;
            };
            byStatus: {
                [status: string]: number;
            };
        };
        engagement: {
            totalVotes: number;
            activeContributors: number;
            averageResponseTime: number;
        };
    };
    /**
     * Get enhancement requests
     */
    getEnhancements(status?: EnhancementRequest['status'], category?: EnhancementRequest['category']): EnhancementRequest[];
    /**
     * Get community contributions
     */
    getContributions(type?: CommunityContribution['type'], status?: CommunityContribution['status']): CommunityContribution[];
    /**
     * Get release history
     */
    getReleases(): ReleaseInfo[];
    private analyzeEnhancement;
    private selectEnhancementsForRelease;
    private calculateEnhancementScore;
    private getEffortPoints;
    private mapContributionTypeToCategory;
    private generateId;
}
//# sourceMappingURL=community-enhancement.d.ts.map