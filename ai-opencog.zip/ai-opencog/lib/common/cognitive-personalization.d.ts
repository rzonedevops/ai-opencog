/**
 * Copyright (c) 2024 Cognitive Intelligence Ventures.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
import { OpenCogService } from './opencog-service';
export interface UserPreferences {
    theme?: 'light' | 'dark' | 'auto';
    layout?: 'classic' | 'modern' | 'minimal';
    fontSize?: number;
    reasoningDepth?: 'shallow' | 'medium' | 'deep';
    learningRate?: 'conservative' | 'moderate' | 'aggressive';
    suggestionFrequency?: 'low' | 'medium' | 'high';
    explanationLevel?: 'brief' | 'detailed' | 'comprehensive';
    notificationStyle?: 'minimal' | 'informative' | 'verbose';
    adaptiveInterface?: boolean;
    contextAwareness?: boolean;
    proactiveAssistance?: boolean;
    preferredLanguages?: string[];
    codingStyle?: 'functional' | 'object-oriented' | 'procedural';
    errorTolerance?: 'strict' | 'moderate' | 'lenient';
}
export interface UserContext {
    currentProject?: string;
    recentFiles?: string[];
    activeWorkspace?: string;
    sessionDuration?: number;
    interactionHistory?: Array<{
        timestamp: number;
        action: string;
        context: string;
        satisfaction?: number;
    }>;
}
export interface PersonalizationProfile {
    userId: string;
    preferences: UserPreferences;
    context: UserContext;
    adaptations: Array<{
        feature: string;
        adaptation: any;
        confidence: number;
        timestamp: number;
    }>;
    learningHistory: Array<{
        timestamp: number;
        insight: string;
        source: 'explicit' | 'implicit';
        strength: number;
    }>;
}
/**
 * Cognitive personalization service that adapts the IDE experience to individual user preferences and behaviors
 */
export declare class CognitivePersonalization {
    protected readonly opencog: OpenCogService;
    private profiles;
    /**
     * Adapt interface and behavior to user preferences
     */
    adaptToUser(userId: string, preferences: UserPreferences): Promise<void>;
    /**
     * Learn from user interactions implicitly
     */
    learnFromInteraction(userId: string, interaction: {
        action: string;
        context: string;
        duration?: number;
        success?: boolean;
        satisfaction?: number;
    }): Promise<void>;
    /**
     * Get personalized recommendations for the user
     */
    getRecommendations(userId: string, context?: string): Promise<Array<{
        type: string;
        description: string;
        confidence: number;
        action?: any;
    }>>;
    /**
     * Update user context (workspace, files, etc.)
     */
    updateContext(userId: string, context: Partial<UserContext>): Promise<void>;
    /**
     * Get user's personalization profile
     */
    getProfile(userId: string): PersonalizationProfile | undefined;
    /**
     * Get or create a profile for the user
     */
    private getOrCreateProfile;
    /**
     * Apply adaptations based on user preferences
     */
    private applyAdaptations;
    /**
     * Analyze interaction patterns to generate insights
     */
    private analyzeInteractionPatterns;
    /**
     * Generate UI-related recommendations
     */
    private generateUIRecommendations;
    private mapReasoningDepth;
    private mapSuggestionFrequency;
    private mapExplanationLevel;
}
//# sourceMappingURL=cognitive-personalization.d.ts.map