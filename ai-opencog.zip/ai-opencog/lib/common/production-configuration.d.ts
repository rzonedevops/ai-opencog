import { PreferenceService } from '@theia/core/lib/browser';
export interface ProductionConfig {
    environment: 'development' | 'staging' | 'production';
    cognitiveServices: {
        enabled: boolean;
        maxConcurrency: number;
        timeout: number;
        retryAttempts: number;
        cacheSize: number;
    };
    performance: {
        memoryLimit: number;
        cpuThreshold: number;
        diskSpaceThreshold: number;
        responseTimeThreshold: number;
    };
    monitoring: {
        enabled: boolean;
        metricsInterval: number;
        alerting: boolean;
        logLevel: 'error' | 'warn' | 'info' | 'debug';
    };
    deployment: {
        containerized: boolean;
        autoScaling: boolean;
        healthCheckInterval: number;
        gracefulShutdownTimeout: number;
    };
}
export interface EnvironmentSettings {
    [key: string]: any;
}
/**
 * Production configuration management service
 */
export declare class ProductionConfigurationService {
    protected readonly preferenceService: PreferenceService;
    private readonly defaultConfig;
    /**
     * Get current production configuration
     */
    getConfiguration(): Promise<ProductionConfig>;
    /**
     * Update configuration settings
     */
    updateConfiguration(updates: Partial<ProductionConfig>): Promise<void>;
    /**
     * Get current environment
     */
    getEnvironment(): Promise<'development' | 'staging' | 'production'>;
    /**
     * Configure cognitive service parameters
     */
    configureCognitiveServices(settings: {
        enabled?: boolean;
        maxConcurrency?: number;
        timeout?: number;
        retryAttempts?: number;
        cacheSize?: number;
    }): Promise<void>;
    /**
     * Configure performance tuning settings
     */
    configurePerformance(settings: {
        memoryLimit?: number;
        cpuThreshold?: number;
        diskSpaceThreshold?: number;
        responseTimeThreshold?: number;
    }): Promise<void>;
    /**
     * Get environment-specific settings
     */
    getEnvironmentSettings(): Promise<EnvironmentSettings>;
    private mergeConfig;
    private applyConfiguration;
}
//# sourceMappingURL=production-configuration.d.ts.map