/**
 * Copyright (c) 2024 Cognitive Intelligence Ventures.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
export interface ResourceMetrics {
    memoryUsage: {
        atomSpace: number;
        learningModels: number;
        cache: number;
        total: number;
    };
    performance: {
        queryLatency: number;
        reasoningLatency: number;
        learningLatency: number;
        throughput: number;
    };
    utilization: {
        cpuUsage: number;
        memoryUtilization: number;
        diskUsage: number;
        networkBandwidth: number;
    };
}
export interface OptimizationStrategy {
    name: string;
    type: 'memory' | 'performance' | 'network' | 'processing';
    enabled: boolean;
    parameters: Record<string, any>;
    priority: number;
}
export interface ResourceThresholds {
    memoryWarning: number;
    memoryCritical: number;
    latencyWarning: number;
    latencyCritical: number;
    cpuWarning: number;
    cpuCritical: number;
}
/**
 * Resource management service for optimizing cognitive system performance
 */
export declare class ResourceManager {
    private metrics;
    private optimizationStrategies;
    private thresholds;
    private monitoringEnabled;
    private monitoringInterval?;
    private lastCleanup;
    private readonly cleanupInterval;
    constructor();
    /**
     * Optimize AtomSpace memory usage
     */
    optimizeAtomSpaceMemory(): Promise<{
        beforeSize: number;
        afterSize: number;
        atomsRemoved: number;
        memoryFreed: number;
    }>;
    /**
     * Distribute processing load across available resources
     */
    distributeProcessing(tasks: Array<{
        id: string;
        type: 'reasoning' | 'learning' | 'pattern_matching';
        priority: number;
        estimatedTime: number;
    }>): Promise<Array<{
        taskId: string;
        assignedCore: number;
        estimatedCompletion: number;
    }>>;
    /**
     * Optimize network communication
     */
    optimizeNetworkCommunication(): Promise<{
        compressionEnabled: boolean;
        batchingEnabled: boolean;
        connectionPoolSize: number;
        estimatedBandwidthSaving: number;
    }>;
    /**
     * Get current resource metrics
     */
    getMetrics(): ResourceMetrics;
    /**
     * Update resource metrics
     */
    updateMetrics(newMetrics: Partial<ResourceMetrics>): void;
    /**
     * Set resource thresholds
     */
    setThresholds(thresholds: Partial<ResourceThresholds>): void;
    /**
     * Enable or disable an optimization strategy
     */
    setOptimizationStrategy(name: string, enabled: boolean, parameters?: Record<string, any>): void;
    /**
     * Get all optimization strategies
     */
    getOptimizationStrategies(): OptimizationStrategy[];
    /**
     * Perform automatic optimization based on current metrics and thresholds
     */
    performAutoOptimization(): Promise<{
        actionsPerformed: string[];
        metricsImprovement: Partial<ResourceMetrics>;
    }>;
    /**
     * Start monitoring resources
     */
    startMonitoring(): void;
    /**
     * Stop monitoring resources
     */
    stopMonitoring(): void;
    /**
     * Dispose resources
     */
    dispose(): void;
    private initializeMetrics;
    private initializeOptimizationStrategies;
    private calculateMemoryOptimization;
    private getAvailableCores;
    private optimizeQueryPerformance;
    private performCleanup;
    private updateResourceMetrics;
    private checkThresholds;
    private calculateMetricsImprovement;
}
//# sourceMappingURL=resource-manager.d.ts.map