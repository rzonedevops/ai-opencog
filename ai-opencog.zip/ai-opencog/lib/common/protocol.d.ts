import { RpcServer } from '@theia/core/lib/common/messaging/proxy-factory';
import { Atom, AtomPattern, ReasoningQuery, LearningData, PatternInput } from './opencog-types';
import { NodeRegistration, NodeHeartbeat, ReasoningCapability } from './distributed-reasoning-types';
/**
 * JSON-RPC protocol extensions for OpenCog operations
 */
export interface OpenCogProtocol {
    'opencog/add-atom': {
        atom: Atom;
    };
    'opencog/query-atoms': {
        pattern: AtomPattern;
    };
    'opencog/remove-atom': {
        atomId: string;
    };
    'opencog/update-atom': {
        atomId: string;
        updates: Partial<Atom>;
    };
    'opencog/reason': {
        query: ReasoningQuery;
    };
    'opencog/learn': {
        data: LearningData;
    };
    'opencog/recognize-patterns': {
        input: PatternInput;
    };
    'opencog/get-atomspace-size': {};
    'opencog/clear-atomspace': {};
    'opencog/export-atomspace': {};
    'opencog/import-atomspace': {
        data: string;
    };
    'distributed-reasoning/submit-task': {
        query: ReasoningQuery;
        constraints?: any;
    };
    'distributed-reasoning/get-task-status': {
        taskId: string;
    };
    'distributed-reasoning/cancel-task': {
        taskId: string;
    };
    'distributed-reasoning/register-node': {
        registration: NodeRegistration;
    };
    'distributed-reasoning/deregister-node': {
        nodeId: string;
    };
    'distributed-reasoning/send-heartbeat': {
        heartbeat: NodeHeartbeat;
    };
    'distributed-reasoning/get-active-nodes': {};
    'distributed-reasoning/get-nodes-by-capability': {
        capability: ReasoningCapability;
    };
    'distributed-reasoning/get-system-stats': {};
    'distributed-reasoning/health-check': {};
}
export interface OpenCogServer extends RpcServer<OpenCogProtocol> {
}
//# sourceMappingURL=protocol.d.ts.map