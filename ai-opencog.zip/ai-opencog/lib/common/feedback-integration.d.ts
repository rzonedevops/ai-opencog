/**
 * Copyright (c) 2024 Cognitive Intelligence Ventures.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 */
import { OpenCogService } from './opencog-service';
import { CognitivePersonalization } from './cognitive-personalization';
export interface FeedbackData {
    id: string;
    userId: string;
    timestamp: number;
    type: 'explicit' | 'implicit';
    source: string;
    context: {
        feature: string;
        action: string;
        environment: string;
        sessionId: string;
    };
    rating?: number;
    sentiment?: 'positive' | 'negative' | 'neutral';
    tags?: string[];
    details?: string;
    metadata?: Record<string, any>;
}
export interface FeedbackAnalysis {
    averageRating: number;
    sentimentDistribution: {
        positive: number;
        negative: number;
        neutral: number;
    };
    commonTags: Array<{
        tag: string;
        count: number;
        sentiment: string;
    }>;
    trends: Array<{
        period: string;
        metric: string;
        value: number;
        change: number;
    }>;
    insights: Array<{
        type: 'improvement' | 'warning' | 'success';
        description: string;
        confidence: number;
        action?: string;
    }>;
}
export interface LearningObjective {
    id: string;
    name: string;
    description: string;
    metrics: string[];
    targetValue: number;
    currentValue: number;
    status: 'active' | 'completed' | 'paused';
    progress: number;
    deadline?: number;
}
export interface ContinuousImprovement {
    objectives: LearningObjective[];
    experiments: Array<{
        id: string;
        name: string;
        hypothesis: string;
        startDate: number;
        endDate?: number;
        status: 'running' | 'completed' | 'cancelled';
        results?: any;
    }>;
    improvements: Array<{
        id: string;
        description: string;
        implementationDate: number;
        impact: number;
        category: string;
    }>;
}
/**
 * Feedback integration system for collecting user feedback and continuous improvement
 */
export declare class FeedbackIntegration {
    protected readonly opencog: OpenCogService;
    protected readonly personalization: CognitivePersonalization;
    private feedbackHistory;
    private learningObjectives;
    private activeExperiments;
    private improvements;
    private nextFeedbackId;
    /**
     * Collect explicit user feedback
     */
    collectExplicitFeedback(feedback: {
        userId: string;
        source: string;
        context: any;
        rating: number;
        sentiment?: 'positive' | 'negative' | 'neutral';
        tags?: string[];
        details?: string;
        metadata?: Record<string, any>;
    }): Promise<string>;
    /**
     * Collect implicit feedback from user interactions
     */
    collectImplicitFeedback(interaction: {
        userId: string;
        source: string;
        context: any;
        behavior: {
            action: string;
            duration?: number;
            completionRate?: number;
            errorRate?: number;
            repetitionCount?: number;
        };
        metadata?: Record<string, any>;
    }): Promise<string>;
    /**
     * Analyze feedback and generate insights
     */
    analyzeFeedback(userId?: string, timeRange?: {
        start: number;
        end: number;
    }): Promise<FeedbackAnalysis>;
    /**
     * Learn from interactions and adapt behavior
     */
    learnFromInteractions(userId: string): Promise<{
        learningPoints: Array<{
            insight: string;
            confidence: number;
        }>;
        adaptations: Array<{
            feature: string;
            change: string;
            reason: string;
        }>;
    }>;
    /**
     * Implement continuous improvement based on feedback
     */
    implementContinuousImprovement(): Promise<ContinuousImprovement>;
    /**
     * Get feedback history for a user
     */
    getFeedbackHistory(userId: string, limit?: number): FeedbackData[];
    /**
     * Get learning objectives
     */
    getLearningObjectives(): LearningObjective[];
    private inferSentiment;
    private inferRatingFromBehavior;
    private extractTagsFromBehavior;
    private getEmptyAnalysis;
    private getCommonSentiment;
    private calculateTrends;
    private generateInsights;
    private identifyFeedbackPatterns;
    private generateAdaptation;
    private analyzeFeedbackAndImprove;
    private createOrUpdateLearningObjective;
    private updateObjectiveProgress;
    private updateExperiments;
}
//# sourceMappingURL=feedback-integration.d.ts.map